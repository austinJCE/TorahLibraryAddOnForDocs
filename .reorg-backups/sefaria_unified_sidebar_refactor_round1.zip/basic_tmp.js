
  var palette = {
    "Commentary": "var(--commentary-blue)",
    "Tanakh": "var(--tanakh-teal)",
    "Midrash": "var(--midrash-green)",
    "Mishnah": "var(--mishnah-blue)",
    "Talmud": "var(--talmud-gold)",
    "Halakhah": "var(--halakhah-red)",
    "Kabbalah": "var(--kabbalah-purple)",
    "Jewish Thought": "var(--philosophy-purple)",
    "Liturgy": "var(--liturgy-rose)",
    "Tosefta": "var(--tanaitic-green)",
    "Chasidut": "var(--chasidut-green)",
    "Musar": "var(--mussar-purple)",
    "Responsa": "var(--responsa-red)",
    "Second Temple": "var(--apocrypha-pink)",
    "Reference": "var(--reference-orange)",
    "Modern Commentary": "var(--modern-works-blue)",
    "System": "var(--sefaria-blue)"
  };

  var titles = {};
  var preferences = {};
  var currentPreviewData = null;
  var preferredTranslationByBook = {};
  var preferredTranslationLanguage = 'en';

  function normalizeVersionLanguage(version) {
    return String((version && (version.actualLanguage || version.language || version.lang)) || '').toLowerCase().trim();
  }

  function versionLanguagePriority(version) {
    var lang = normalizeVersionLanguage(version);
    if (lang === preferredTranslationLanguage) return 0;
    if (lang === 'en') return 1;
    return 2;
  }
  var debounceState = null;
  var debounceDuration = 300;

  function fetchIndexTitles() {
    fetch('https://www.sefaria.org/api/index')
      .then(function(response) { return response.json(); })
      .then(parseArray)
      .catch(function() {});
  }

  function parseArray(json) {
    (json || []).forEach(getContents);
  }

  function getContents(json) {
    if (!json) return;
    if (json.contents) {
      getContents(json.contents);
    } else if (Array.isArray(json)) {
      parseArray(json);
    } else if (json.title) {
      titles[json.title] = json;
    }
  }

  function isHebrew(text) {
    var heCount = 0;
    var enCount = 0;
    var punctuationRE = /[0-9 .,'"?!;:\-=@#$%^&*()/<>]/;
    text = String(text || '');
    for (var i = 0; i < Math.min(200, text.length); i++) {
      if (punctuationRE.test(text[i])) continue;
      if (text.charCodeAt(i) > 0x590 && text.charCodeAt(i) < 0x5ff) heCount++;
      else enCount++;
    }
    return heCount > enCount;
  }

  function getWidthOfInput() {
    var inputEl = document.getElementById('inputBox');
    var tmp = document.createElement('div');
    var styles = window.getComputedStyle(inputEl);
    var cssText = Array.prototype.slice.call(styles).reduce(function(css, propertyName) {
      return css + propertyName + ':' + styles.getPropertyValue(propertyName) + ';';
    }, '');
    tmp.style.cssText = cssText;
    tmp.style.removeProperty('width');
    tmp.style.removeProperty('min-width');
    tmp.style.removeProperty('min-inline-size');
    tmp.style.removeProperty('inline-size');
    tmp.innerHTML = (inputEl.value || '').trim().replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    document.body.appendChild(tmp);
    var width = tmp.getBoundingClientRect().width;
    document.body.removeChild(tmp);
    return width;
  }

  function updateHelperPromptText(text) {
    var helper = document.getElementById('helperCompletionText');
    helper.innerHTML = text || '';
    helper.style.insetInlineStart = getWidthOfInput() + 'px';
  }

  function generateHelperText(d) {
    var text = document.getElementById('inputBox').value;
    if (d && d.sections && d.addressExamples) {
      var separator = isHebrew(text) ? ' ' : ':';
      var remaining = isHebrew(text) ? d.heAddressExamples.slice(d.sections.length).join(separator) : d.addressExamples.slice(d.sections.length).join(separator);
      if (d.sections.length > 0 && !(/[:-]$/.test(text))) {
        remaining = separator + remaining;
      }
      return remaining;
    }
    return '';
  }

  function pad(arr, len, filler) {
    return Array.from({ length: len }, function(_, index) {
      return arr[index] !== undefined ? arr[index] : filler;
    });
  }

  function intToDaf(i) {
    i += 1;
    var daf = Math.ceil(i / 2);
    return daf + (i % 2 ? 'a' : 'b');
  }

  function dafToInt(daf) {
    var amud = daf.slice(-1);
    var index = parseInt(daf.slice(0, -1), 10) - 1;
    return amud === 'a' ? index * 2 : index * 2 + 1;
  }

  function getOffsets(data, length) {
    var offsets = data && data.index_offsets_by_depth && data.index_offsets_by_depth[data.textDepth];
    if (offsets === undefined) {
      return Array(length).fill(0);
    }
    if (typeof offsets === 'number') {
      return [offsets];
    }
    return offsets.flat ? offsets.flat() : offsets;
  }

  function flattenSegmentText(value) {
    return Array.isArray(value) ? value.flat(Infinity).join(' ') : (value || '');
  }

  function makeSegments(data) {
    if (!data || data.error) return [];

    var segments = [];
    var highlight = data.sections.length === data.textDepth;
    var wrapEn = typeof data.text === 'string';
    var wrapHe = typeof data.he === 'string';
    var en = wrapEn ? [data.text] : (data.text || []);
    var he = wrapHe ? [data.he] : (data.he || []);
    var topLength = Math.max(en.length, he.length);

    en = pad(en, topLength, '');
    he = pad(he, topLength, '');

    var offsets = getOffsets(data, topLength);
    var start = (data.textDepth === data.sections.length) ? data.sections.slice(-1)[0] : 1 + offsets[0];

    if (!data.isSpanning) {
      for (var i = 0; i < topLength; i++) {
        var number = i + start;
        var delim = data.textDepth === 1 ? ' ' : ':';
        var ref = (data.sectionRef || data.ref || '') + delim + number;
        segments.push({
          ref: ref,
          en: flattenSegmentText(en[i]),
          he: flattenSegmentText(he[i]),
          number: number,
          highlight: highlight && number >= data.sections.slice(-1)[0] && number <= data.toSections.slice(-1)[0]
        });
      }
      return segments;
    }

    for (var n = 0; n < topLength; n++) {
      var en2 = typeof en[n] === 'string' ? [en[n]] : en[n];
      var he2 = typeof he[n] === 'string' ? [he[n]] : he[n];
      var length = Math.max(en2.length, he2.length);

      en2 = pad(en2, length, '');
      he2 = pad(he2, length, '');

      var baseSection = data.sections.slice(0, -2).join(':');
      var baseRef = baseSection ? data.book + ' ' + baseSection : data.book;
      var delim = baseSection ? ':' : ' ';

      start = n === 0 ? start : 1 + (offsets[n] || 0);
      for (var j = 0; j < length; j++) {
        var startSection = data.sections.slice(-2)[0];
        var section = typeof startSection === 'string' ? intToDaf(n + dafToInt(startSection)) : n + startSection;
        var num = j + start;
        segments.push({
          ref: baseRef + delim + section + ':' + num,
          en: flattenSegmentText(en2[j]),
          he: flattenSegmentText(he2[j]),
          number: num,
          highlight: highlight && (
            (n === 0 && num >= data.sections.slice(-1)[0]) ||
            (n === topLength - 1 && num <= data.toSections.slice(-1)[0]) ||
            (n > 0 && n < topLength - 1)
          )
        });
      }
    }

    if (!segments.length) {
      segments.push({
        ref: data.ref,
        en: flattenSegmentText(data.text),
        he: flattenSegmentText(data.he),
        number: 1,
        highlight: true
      });
    }

    return segments;
  }

  function renderPreview(data) {
    currentPreviewData = data;
    var container = document.querySelector('#previewContainer .textContainer');
    container.innerHTML = '';
    var segments = makeSegments(data);
    segments.forEach(function(segment) {
      var wrapper = document.createElement('div');
      var heClass = 'segment he' + (segment.highlight ? ' highlight' : '');
      var enClass = 'segment en' + (segment.highlight ? ' highlight' : '');
      wrapper.innerHTML = '<span class="' + heClass + '">' + segment.number + '. ' + (segment.he || '') + '</span>' +
        '<span class="' + enClass + '">' + (segment.en || '') + '</span>';
      container.appendChild(wrapper);
    });
    document.getElementById('addSourceButton').disabled = false;
    document.getElementById('open-on-sefaria').disabled = false;
  }

  function applyLayoutClass() {
    var value = document.getElementById('addFormat').value;
    var preview = document.getElementById('previewContainer');
    var layoutSetting = document.getElementById('bilingualLayoutSetting').value || 'he-right';
    preview.classList.remove('en', 'he', 'bi', 'stack', 'sbs');
    if (value === 'en') preview.classList.add('en');
    else if (value === 'he') preview.classList.add('he');
    else {
      preview.classList.add('bi');
      preview.classList.add(value === 'sbs' ? 'sbs' : 'stack');
    }
    var translationContainer = document.querySelector('.translation-version-control');
    if (translationContainer) translationContainer.style.display = value === 'he' ? 'none' : 'block';
    document.querySelectorAll('.mode-card').forEach(function(button) {
      var active = button.getAttribute('data-mode') === (value === 'stack' || value === 'sbs' ? 'both' : value);
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-checked', active ? 'true' : 'false');
    });
    var layoutValue = value === 'stack' ? 'he-top' : layoutSetting;
    document.querySelectorAll('.bilingual-layout-wrapper').forEach(function(node) {
      node.style.display = value === 'en' || value === 'he' ? 'none' : '';
    });
    document.querySelectorAll('.layout-option').forEach(function(button) {
      var active = button.getAttribute('data-layout') === layoutValue;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-checked', active ? 'true' : 'false');
    });
  }

  function populateTranslationOptions(data, preferredValue) {
    var select = document.getElementById('translationSetter');
    while (select.options.length) select.remove(0);
    var translations = ((data && data.versions) || []).filter(function(version) {
      return normalizeVersionLanguage(version) !== 'he';
    }).sort(function(a, b) {
      var diff = versionLanguagePriority(a) - versionLanguagePriority(b);
      if (diff !== 0) return diff;
      return String((a && a.versionTitle) || '').localeCompare(String((b && b.versionTitle) || ''));
    });

    translations.forEach(function(version) {
      var lang = normalizeVersionLanguage(version) || 'other';
      var label = ((lang === 'en' ? 'English' : lang.toUpperCase()) + ' – ' + version.versionTitle);
      select.add(new Option(label, version.versionTitle));
    });

    if (!translations.length) {
      select.add(new Option('No translation options available', ''));
      select.disabled = true;
      return;
    }
    select.disabled = false;
    if (preferredValue) select.value = preferredValue;
    if (!select.value && translations.length) select.value = translations[0].versionTitle;
  }

  function getSelectedTranslation() {
    var select = document.getElementById('translationSetter');
    return select && !select.disabled ? select.value : '';
  }

  function syncVersionControlContainers() {
    var translationContainer = document.querySelector('.translation-version-control');
    var hebrewContainer = document.querySelector('.hebrew-version-control');
    if (translationContainer && translationContainer.firstChild !== document.getElementById('translationSetter')) {
      translationContainer.innerHTML = '';
      translationContainer.appendChild(document.getElementById('translationSetter'));
    }
    if (hebrewContainer && hebrewContainer.firstChild !== document.getElementById('hebrewVersionSetter')) {
      hebrewContainer.innerHTML = '';
      hebrewContainer.appendChild(document.getElementById('hebrewVersionSetter'));
    }
  }

  function populateHebrewVersionOptions(data) {
    var select = document.getElementById('hebrewVersionSetter');
    while (select.options.length) select.remove(0);
    var versions = ((data && data.versions) || []).filter(function(version) { return version.language === 'he'; });
    select.add(new Option('Default original edition', ''));
    versions.forEach(function(version) {
      select.add(new Option(version.versionTitle, version.versionTitle));
    });
    select.disabled = versions.length === 0;
  }

  function loadPreview(ref, explicitTranslation) {
    if (!ref) return;
    var translation = explicitTranslation || '';
    var params = new URLSearchParams({
      ven: translation,
      stripItags: 1,
      context: 1,
      commentary: 0
    });
    document.querySelector('.hide').style.display = 'flex';
    fetch('https://www.sefaria.org/api/texts/' + encodeURIComponent(ref) + '?' + params.toString())
      .then(function(response) { return response.json(); })
      .then(function(data) {
        document.querySelector('.hide').style.display = 'none';
        if (data && data.book && getSelectedTranslation()) {
          preferredTranslationByBook[data.book] = getSelectedTranslation();
        }
        populateTranslationOptions(data, explicitTranslation || preferredTranslationByBook[data.book] || '');
        populateHebrewVersionOptions(data);
        syncVersionControlContainers();
        renderPreview(data);
        applyLayoutClass();
        document.getElementById('suggestionBox').style.display = 'none';
        document.querySelector('.display-panel').classList.add('active');
      })
      .catch(function() {
        document.querySelector('.hide').style.display = 'none';
      });
  }

  function mapResults(results) {
    var selectBox = document.getElementById('suggestionBox');
    selectBox.options.length = 0;
    (results || []).forEach(function(result) {
      var option = document.createElement('option');
      option.classList.add('suggestion');
      option.value = result.name;
      option.textContent = result.name;
      option.style.borderInlineStartColor = result.borderColor || 'var(--sefaria-blue)';
      selectBox.appendChild(option);
    });
    selectBox.style.display = results && results.length ? 'block' : 'none';
  }

  function setInputBoxValue() {
    var value = document.getElementById('suggestionBox').value;
    document.getElementById('inputBox').value = value + ' ';
    handleAutocomplete();
  }

  function handleAutocomplete() {
    var input = document.getElementById('inputBox');
    var currentValue = input.value || '';
    var text = /[:-]$/.test(currentValue) ? currentValue.slice(0, -1) : currentValue;
    var direction = isHebrew(text) ? 'rtl' : 'ltr';
    document.querySelector('.inputContainer').style.direction = direction;
    document.querySelector('.suggestionBoxContainer').style.direction = direction;

    if (!text.trim()) {
      document.getElementById('suggestionBox').style.display = 'none';
      document.querySelector('#previewContainer .textContainer').innerHTML = '';
      document.querySelector('.display-panel').classList.remove('active');
      updateHelperPromptText('');
      document.getElementById('addSourceButton').disabled = true;
      document.getElementById('open-on-sefaria').disabled = true;
      currentPreviewData = null;
      return;
    }

    fetch('https://www.sefaria.org/api/name/' + encodeURIComponent(text) + '?ref_only=1&limit=5')
      .then(function(response) { return response.json(); })
      .then(function(data) {
        updateHelperPromptText(generateHelperText(data));
        if (data.is_section || data.is_segment) {
          loadPreview(text, getSelectedTranslation());
          return;
        }
        document.getElementById('addSourceButton').disabled = true;
        document.getElementById('open-on-sefaria').disabled = true;
        currentPreviewData = null;
        var results = (data.completion_objects || []).map(function(suggestion) {
          var title = titles[suggestion.key] || {};
          return {
            name: suggestion.title,
            borderColor: palette[title.primary_category] || 'var(--sefaria-blue)'
          };
        });
        mapResults(results);
      })
      .catch(function() {});
  }

  function onAutocompleteKeyDown() {
    if (debounceState) clearTimeout(debounceState);
    debounceState = setTimeout(handleAutocomplete, debounceDuration);
  }

  function getInsertionOptions() {
    var addFormat = document.getElementById('addFormat').value;
    var singleLanguage = null;
    var bilingualLayout = document.getElementById('bilingualLayoutSetting').value || preferences.bilingual_layout_default || 'he-right';
    if (addFormat === 'en' || addFormat === 'he') {
      singleLanguage = addFormat;
    } else if (addFormat === 'stack') {
      bilingualLayout = 'he-top';
    } else if (bilingualLayout === 'he-top') {
      bilingualLayout = 'he-right';
    }

    return {
      singleLanguage: singleLanguage,
      bilingualLayout: bilingualLayout,
      includeTranslationSourceInfo: String(preferences.include_translation_source_info) === 'true',
      includeTransliteration: String(preferences.include_transliteration_default) === 'true',
      insertSefariaLink: String(preferences.insert_sefaria_link_default) !== 'false',
      showLineMarkers: String(preferences.show_line_markers_default) !== 'false',
      insertCitationOnly: String(preferences.insert_citation_default) === 'true'
    };
  }

  function insertSource() {
    var ref = (document.getElementById('inputBox').value || '').trim();
    if (!ref) return;
    var versions = { en: getSelectedTranslation(), he: '' };
    var options = getInsertionOptions();
    document.querySelector('.hide').style.display = 'flex';
    google.script.run.withSuccessHandler(function(resolved) {
      google.script.run.withSuccessHandler(function() {
        document.querySelector('.hide').style.display = 'none';
      }).withFailureHandler(function(error) {
        document.querySelector('.hide').style.display = 'none';
        alert((error && error.message) || 'Could not insert this source.');
      }).insertReference(
        resolved,
        options.singleLanguage,
        options.showLineMarkers,
        ref,
        options.includeTranslationSourceInfo,
        options.bilingualLayout,
        options.insertSefariaLink,
        options.includeTransliteration,
        options.insertCitationOnly
      );
    }).withFailureHandler(function(error) {
      document.querySelector('.hide').style.display = 'none';
      alert((error && error.message) || 'Could not resolve this source.');
    }).findReference(ref, versions);
  }

  document.getElementById('inputBox').addEventListener('keyup', onAutocompleteKeyDown);
  document.querySelectorAll('.mode-card').forEach(function(button) {
    button.addEventListener('click', function() {
      var mode = button.getAttribute('data-mode');
      if (mode === 'both') {
        var layoutSetting = document.getElementById('bilingualLayoutSetting').value || 'he-right';
        document.getElementById('addFormat').value = layoutSetting === 'he-top' ? 'stack' : 'sbs';
      } else {
        document.getElementById('addFormat').value = mode;
      }
      applyLayoutClass();
    });
  });

  document.querySelectorAll('.layout-option').forEach(function(button) {
    button.addEventListener('click', function() {
      var layout = button.getAttribute('data-layout');
      var currentMode = document.querySelector('.mode-card.is-active');
      var mode = currentMode ? currentMode.getAttribute('data-mode') : 'both';
      document.getElementById('bilingualLayoutSetting').value = layout;
      if (mode === 'both') {
        document.getElementById('addFormat').value = layout === 'he-top' ? 'stack' : 'sbs';
        applyLayoutClass();
      }
    });
  });

  document.getElementById('translationSetter').addEventListener('change', function() {
    var ref = (document.getElementById('inputBox').value || '').trim();
    if (ref) loadPreview(ref, getSelectedTranslation());
  });
  document.getElementById('addSourceButton').addEventListener('click', insertSource);
  document.getElementById('openPreferencesButton').addEventListener('click', function() { google.script.run.preferencesPopup(); });
  document.getElementById('linkTextsButton').addEventListener('click', function() { google.script.run.linkTextsWithSefaria(); });
  document.getElementById('transformNamesButton').addEventListener('click', function() { google.script.run.transformDivineNames(); });
  document.getElementById('open-on-sefaria').addEventListener('click', function() {
    var ref = (document.getElementById('inputBox').value || '').trim();
    if (ref) {
      window.open('https://www.sefaria.org/' + encodeURIComponent(ref).replace(/%20/g, '_'), '_blank');
    }
  });

  google.script.run.withSuccessHandler(function(receivedPreferences) {
    preferences = receivedPreferences || {};
    preferredTranslationLanguage = String(preferences.preferred_translation_language || 'en').toLowerCase();
    var defaultMode = preferences.output_mode_default || 'both';
    document.getElementById('bilingualLayoutSetting').value = preferences.bilingual_layout_default || 'he-right';
    document.getElementById('addFormat').value = defaultMode === 'he' ? 'he' : (defaultMode === 'en' ? 'en' : ((preferences.bilingual_layout_default || 'he-right') === 'he-top' ? 'stack' : 'sbs'));
    syncVersionControlContainers();
    applyLayoutClass();
  }).getPreferences();

  fetchIndexTitles();
