Bundle C patch
- Session Library positioned above footer
- Did-you-mean click populates search and reruns
- Restore all button visibility fixed
- Compact translation language icon dropdown added
- Recent panel suppressed
- Result metadata row polish and pin/session styles improved
- Sefaria URL regex normalization bug fixed
