import fs from 'fs';

const checks = [
  ['ui_api.js.html', 'App.api'],
  ['ui_api.js.html', '.call'],
  ['ui_dom.js.html', 'App.dom'],
  ['ui_feedback.js.html', 'App.feedback'],
  ['ui_state.js.html', 'App.state'],
  ['sidebar.page.js.html', "App.register('sidebar'"],
  ['preferences.page.js.html', "App.register('preferences'"],
  ['ai_lesson.page.js.html', "App.register('ai_lesson'"],
  ['surprise-me.page.js.html', "App.register('surprise-me'" ]
];

let failed = false;

for (const [file, text] of checks) {
  if (!fs.existsSync(file)) {
    console.error(`[FAIL] missing file: ${file}`);
    failed = true;
    continue;
  }
  const content = fs.readFileSync(file, 'utf8');
  if (!content.includes(text)) {
    console.error(`[FAIL] ${file} missing contract text: ${text}`);
    failed = true;
  }
}

if (failed) process.exit(1);
console.log('[PASS] Shared/page JS contracts look correct.');
