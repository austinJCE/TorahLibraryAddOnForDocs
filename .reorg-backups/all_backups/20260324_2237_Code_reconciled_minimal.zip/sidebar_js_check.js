
// no need for $(document).ready() since this script is loaded at the end of the page
// Input stays enabled; legacy disabling removed.
var data = {};
var titles = [];
var latestResolveRequestId = 0;
var latestQueryRequestId = 0;
var latestDirectRefValidationRequestId = 0;
var selectedResultKey = null;
var selectedResultSummary = null;
var selectedRefValue = null;
var queryState = { rawLibraryMatches: [], rawSearchResults: [], libraryMatches: [], searchResults: [] };
var resultPostProcessState = { availableCorpora: [], removedCorpora: [] };
var resultsCollapsed = false;
var pendingPreferredVersions = null;
var translationAvailabilityByRef = {};
var hasResolvedReference = false;
var searchDebounceHandle = null;
var keyboardResultIndex = -1;
var resultsLoading = false;
var MAX_FUZZY_SUGGESTIONS = 3;
var preferredTranslationLanguage = "en";
var sidebarSessionId = null;
var accountPreferences = {};
var sessionPreferences = {};
var effectivePreferences = {};

function clonePlainObject(value) {
  var out = {};
  value = value || {};
  Object.keys(value).forEach(function (key) { out[key] = value[key]; });
  return out;
}

function mergePreferenceLayers(base, override) {
  var merged = clonePlainObject(base);
  override = override || {};
  Object.keys(override).forEach(function (key) { merged[key] = override[key]; });
  return merged;
}

function isAdvancedSessionMode() {
  return appMode === 'advanced';
}

function hasSessionOverrides() {
  return Object.keys(sessionPreferences || {}).length > 0;
}

function syncSessionOverrideButtons() {
  var isAdvanced = isAdvancedSessionMode();
  $('.session-override-actions').toggle(isAdvanced);
  $('.reset-session-overrides-button, .save-session-defaults-button').prop('disabled', !isAdvanced || !hasSessionOverrides());
  $('#open-session-library').prop('disabled', !isAdvanced);
}

function syncAiQuickActionState() {
  var enabled = String((effectivePreferences || {}).experimental_ai_source_sheet_enabled) === 'true' || (effectivePreferences || {}).experimental_ai_source_sheet_enabled === true;
  $('.open-ai-lesson-tool').prop('disabled', !enabled).attr('aria-disabled', enabled ? 'false' : 'true');
}

function applyEffectivePreferencesToUI() {
  mergePreferenceDefaults(effectivePreferences);
  syncDisplayModeCards();
  syncLayoutCards();
  updateBilingualLayoutVisibility();
  updateTranslationDetailsVisibility();
  updateHebrewOptionsVisibility();
  updateVersionControlsVisibility();
  updateTransliterationVisibility();
  updateInsertionModeVisibility();
  updateTranslationLanguageVisibility();
  syncSessionOverrideButtons();
  syncAiQuickActionState();
}

function saveAccountPreference(payload, onDone) {
  google.script.run.withSuccessHandler(function (updated) {
    accountPreferences = clonePlainObject(updated || accountPreferences);
    effectivePreferences = isAdvancedSessionMode() ? mergePreferenceLayers(accountPreferences, sessionPreferences) : mergePreferenceLayers(accountPreferences, {});
    syncSessionOverrideButtons();
    if (typeof onDone === 'function') onDone(updated);
  }).setAccountPreferences(payload || {});
}

function saveSessionPreference(payload, onDone) {
  if (!sidebarSessionId) {
    if (typeof onDone === 'function') onDone(sessionPreferences);
    return;
  }
  google.script.run.withSuccessHandler(function (updated) {
    sessionPreferences = clonePlainObject(updated || sessionPreferences);
    effectivePreferences = mergePreferenceLayers(accountPreferences, sessionPreferences);
    syncSessionOverrideButtons();
    if (typeof onDone === 'function') onDone(updated);
  }).setSidebarSessionState(sidebarSessionId, payload || {});
}

function saveSidebarPreference(payload, onDone, forceAccountSave) {
  if (forceAccountSave || !isAdvancedSessionMode()) {
    saveAccountPreference(payload, onDone);
  } else {
    saveSessionPreference(payload, onDone);
  }
}

function resetSessionOverrides(onDone) {
  if (!sidebarSessionId) return;
  google.script.run.withSuccessHandler(function () {
    sessionPreferences = {};
    effectivePreferences = mergePreferenceLayers(accountPreferences, {});
    applyEffectivePreferencesToUI();
    if (hasResolvedReference && data && data.ref) refreshSelectedResult();
    updateModeDependentSections();
    if (typeof onDone === 'function') onDone();
  }).clearSidebarSessionState(sidebarSessionId);
}

function saveSessionAsDefaults(onDone) {
  if (!sidebarSessionId) return;
  google.script.run.withSuccessHandler(function (updated) {
    accountPreferences = clonePlainObject(updated || accountPreferences);
    sessionPreferences = {};
    effectivePreferences = mergePreferenceLayers(accountPreferences, {});
    applyEffectivePreferencesToUI();
    updateModeDependentSections();
    if (typeof onDone === 'function') onDone(updated);
  }).saveSidebarSessionAsAccountDefaults(sidebarSessionId);
}

var corpusColorClassMap = {
  tanakh: 'corpus-accent-tanakh',
  mishnah: 'corpus-accent-mishnah',
  talmud: 'corpus-accent-talmud',
  midrash: 'corpus-accent-midrash',
  halakhah: 'corpus-accent-halakhah',
  liturgy: 'corpus-accent-liturgy',
  kabbalah: 'corpus-accent-kabbalah',
  philosophy: 'corpus-accent-philosophy',
  chasidut: 'corpus-accent-chasidut',
  musar: 'corpus-accent-musar',
  commentary: 'corpus-accent-commentary',
  reference: 'corpus-accent-reference',
  'modern-works': 'corpus-accent-modernworks',
  apocrypha: 'corpus-accent-apocrypha',
  tanaitic: 'corpus-accent-tanaitic'
};

function escapeHTML(value) {
  return String(value || "")
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/\"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function parseStoredArrayPreference(value, fallback) {
  fallback = Array.isArray(fallback) ? fallback : [];
  if (Array.isArray(value)) return value.filter(Boolean);
  var raw = String(value || '').trim();
  if (!raw) return fallback.slice();
  try {
    var parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter(Boolean) : fallback.slice();
  } catch (error) {
    return raw ? raw.split(',').map(function (part) { return String(part || '').trim(); }).filter(Boolean) : fallback.slice();
  }
}

function mergePreferenceDefaults(preferences) {
  preferences = preferences || {};
  if (preferences.include_translation_source_info == "true") {
    $('.include-translation-source-info').prop('checked', true);
  }
  $('.wants-vowels').prop('checked', preferences.nekudot !== "false");
  $('.wants-cantillation').prop('checked', preferences.teamim !== "false");
  $('.include-transliteration').prop('checked', String(preferences.include_transliteration_default) === "true");
  $('.insert-sefaria-link').prop('checked', preferences.insert_sefaria_link_default !== "false");
  $('.insert-citation-only').prop('checked', String(preferences.insert_citation_default) === "true");
  $('.wants-pesukim').prop('checked', preferences.show_line_markers_default !== "false");
  $('.output-mode-selection').val(preferences.output_mode_default || 'both');
  $('.bilingual-layout-selection').val(preferences.bilingual_layout_default || 'he-right');
  $('.translation-only-filter').prop('checked', preferences.last_translation_only_filter === "true");
  $('.search-sort-select').val(preferences.last_search_sort_mode || 'relevance');
  $('.wants-relevance').prop('checked', preferences.last_search_relevance_sort !== "false");

  preferredTranslationLanguage = String(preferences.preferred_translation_language || 'en').toLowerCase();
  var savedTranslationLanguages = parseStoredArrayPreference(preferences.last_translation_languages, ['en']);
  $('.translation-language-option').prop('checked', false);
  var useAnyTranslationLanguage = !savedTranslationLanguages.length || savedTranslationLanguages.indexOf('any') >= 0;
  $('.translation-language-any').prop('checked', useAnyTranslationLanguage);
  if (!useAnyTranslationLanguage) {
    savedTranslationLanguages.forEach(function (value) {
      $('.translation-language-option[value="' + value.replace(/([\"'])/g, '\$1') + '"]').prop('checked', true);
    });
  }
}

function getSidebarTransliterationScheme() {
  return String((effectivePreferences && effectivePreferences.transliteration_scheme) || 'simple_english');
}

function getSidebarTransliterationLabel(value) {
  var labels = {
    none: 'None',
    simple_english: "ha-sefer kol-ha'am",
    traditional: "ha-sēfer kol-hā-ʿam",
    modern_israeli: "ha-sefer kol-ha'am",
    ashkenazi: "ha-seifer kol-ho'om",
    academic_full: "ha-sēfer kol-hā-ʿām",
    ipa_modern: "haˈsefeʁ kol haˈʔam",
    ipa_tiberian: "hasˈseːfɛr kɔl hɔːˈʕɔm"
  };
  return labels[value] || labels.simple_english;
}

function closeSidebarTransliterationMenu() {
  $('#sidebar-transliteration-menu').addClass('hidden');
  $('#sidebar-transliteration-toggle').attr('aria-expanded', 'false');
}

function updateSidebarCompositionCard() {
  var vowelsOn = $('.wants-vowels').is(':checked');
  var cantOn = $('.wants-cantillation').is(':checked');
  var transliterationOn = $('.include-transliteration').is(':checked');
  var linkOn = $('.insert-sefaria-link').is(':checked');
  var scheme = transliterationOn ? getSidebarTransliterationScheme() : 'none';

  $('#sidebar-composition-title-toggle').toggleClass('is-linked', linkOn).attr('aria-pressed', linkOn ? 'true' : 'false');
  $('#sidebar-vowels-toggle').toggleClass('is-off', !vowelsOn).attr('aria-pressed', vowelsOn ? 'true' : 'false');
  $('#sidebar-cantillation-toggle').toggleClass('is-off', !cantOn).attr('aria-pressed', cantOn ? 'true' : 'false');

  $('.sidebar-composition-hebrew-text--full').prop('hidden', !(vowelsOn && cantOn));
  $('.sidebar-composition-hebrew-text--no-cantillation').prop('hidden', !(vowelsOn && !cantOn));
  $('.sidebar-composition-hebrew-text--consonants').prop('hidden', !!vowelsOn);

  $('#sidebar-transliteration-toggle').text(getSidebarTransliterationLabel(scheme)).toggleClass('is-none', scheme === 'none').attr('data-value', scheme);
  $('.sidebar-transliteration-option').each(function () {
    $(this).toggleClass('is-selected', $(this).attr('data-value') === scheme);
  });

  $('#sidebar-composition-status').text(
    'Link ' + (linkOn ? 'on' : 'off') +
    ' · Cantillation ' + (cantOn ? 'on' : 'off') +
    ' · Vowels ' + (vowelsOn ? 'on' : 'off') +
    ' · Transliteration: ' + (scheme === 'none' ? 'off' : scheme.replace(/_/g, ' '))
  );
}

function bindSidebarCompositionCard() {
  $('#sidebar-composition-title-toggle').off('click').on('click', function () {
    $('.insert-sefaria-link').prop('checked', !$('.insert-sefaria-link').is(':checked')).trigger('change');
  });
  $('#sidebar-vowels-toggle').off('click').on('click', function () {
    $('.wants-vowels').prop('checked', !$('.wants-vowels').is(':checked')).trigger('change');
  });
  $('#sidebar-cantillation-toggle').off('click').on('click', function () {
    $('.wants-cantillation').prop('checked', !$('.wants-cantillation').is(':checked')).trigger('change');
  });
  $('#sidebar-transliteration-toggle').off('click').on('click', function (event) {
    event.preventDefault();
    event.stopPropagation();
    $('#sidebar-transliteration-menu').toggleClass('hidden');
    $(this).attr('aria-expanded', $('#sidebar-transliteration-menu').hasClass('hidden') ? 'false' : 'true');
  });
  $('.sidebar-transliteration-option').off('click').on('click', function () {
    var value = $(this).attr('data-value');
    if (value === 'none') {
      $('.include-transliteration').prop('checked', false);
      saveSidebarPreference({ include_transliteration_default: false }, function () {
        effectivePreferences.transliteration_scheme = getSidebarTransliterationScheme();
        updateSidebarCompositionCard();
      });
    } else {
      $('.include-transliteration').prop('checked', true);
      saveSidebarPreference({ include_transliteration_default: true, transliteration_scheme: value }, function () {
        effectivePreferences.transliteration_scheme = value;
        updateSidebarCompositionCard();
      });
    }
    closeSidebarTransliterationMenu();
  });
  $(document).off('click.sidebarCompositionDismiss').on('click.sidebarCompositionDismiss', function (event) {
    if ($(event.target).closest('.sidebar-composition-transliteration-wrap').length) return;
    closeSidebarTransliterationMenu();
  });
}

google.script.run.withSuccessHandler(function (bootstrap) {
  sidebarSessionId = (bootstrap && bootstrap.sessionId) || null;
  accountPreferences = clonePlainObject((bootstrap && (bootstrap.accountPreferences || bootstrap.preferences)) || {});
  sessionPreferences = clonePlainObject((bootstrap && bootstrap.sessionState) || {});
  effectivePreferences = clonePlainObject((bootstrap && (bootstrap.effectivePreferences || bootstrap.preferences)) || accountPreferences);
  var bootstrapMode = (bootstrap && bootstrap.mode) || window.INITIAL_SIDEBAR_MODE || 'basic';
  setSidebarMode(bootstrapMode, true);
  applyEffectivePreferencesToUI();
  bindSidebarCompositionCard();
  updateSidebarCompositionCard();
  loadSessionLibrary();
}).getSidebarBootstrapData(window.INITIAL_SIDEBAR_MODE || 'basic');

$('.include-translation-source-info').on('change', function () {
  saveSidebarPreference({
    include_translation_source_info: $('.include-translation-source-info').is(':checked')
  });
});

$('.include-transliteration').on('change', function () {
  saveSidebarPreference({
    include_transliteration_default: $('.include-transliteration').is(':checked')
  }, function () {
    updateSidebarCompositionCard();
  });
});

$('.insert-citation-only').on('change', function () {
  saveSidebarPreference({
    insert_citation_default: $('.insert-citation-only').is(':checked')
  }, refreshSelectedResult, appMode !== 'advanced');
  updateInsertionModeVisibility();
});

$('.insert-sefaria-link').on('change', function () {
  saveSidebarPreference({
    insert_sefaria_link_default: $('.insert-sefaria-link').is(':checked')
  }, function () {
    updateSidebarCompositionCard();
  });
});

$('.wants-pesukim').on('change', function () {
  saveSidebarPreference({
    show_line_markers_default: $('.wants-pesukim').is(':checked')
  });
});

$('.wants-vowels, .wants-cantillation').on('change', function () {
  saveSidebarPreference({
    nekudot: $('.wants-vowels').is(':checked'),
    teamim: $('.wants-cantillation').is(':checked')
  }, function () {
    updateSidebarCompositionCard();
    refreshSelectedResult();
  });
});

function saveLastUsedSearchSettings() {
  saveSidebarPreference({
    last_translation_languages: JSON.stringify(getCheckedValues('.translation-language-option')),
    last_translation_only_filter: $('.translation-only-filter').is(':checked'),
    last_search_sort_mode: $('.search-sort-select').val() || 'relevance',
    last_search_relevance_sort: $('.wants-relevance').length ? $('.wants-relevance').is(':checked') : true
  });
}

function buildPreviewLoadingHTML(message) {
  var text = String(message || 'Loading preview…').trim();
  return "<div class='preview-loading' role='status' aria-live='polite'><span class='preview-loading-spinner' aria-hidden='true'></span><span>" + escapeHTML(text) + "</span></div>";
}

function setInsertButtonState(enabled) {
  $('#insert-source').prop('disabled', !enabled);
}

function updatePesukimAvailability(response) {
  var supportsLineMarkers = !!(response && (Array.isArray(response.he) || Array.isArray(response.text) || response.lineMarkersAvailable === true));
  $('.pesukim-wrapper').toggle(supportsLineMarkers);
  $('.wants-pesukim').prop('disabled', !supportsLineMarkers);
  if (!supportsLineMarkers) {
    $('.wants-pesukim').prop('checked', false);
    $('.pesukim-help').text('Line markers are unavailable for this selection (single-block text).');
  } else {
    if (!$('.wants-pesukim').prop('checked')) {
      $('.wants-pesukim').prop('checked', true);
    }
    $('.pesukim-help').text('Applies to segmented refs (e.g., verse/line ranges).');
  }
}

function updateBilingualLayoutVisibility() {
  var outputMode = $('.output-mode-selection').val();
  $('.bilingual-layout-wrapper').toggle(outputMode === 'both');
}

function updateTranslationDetailsVisibility() {
  var outputMode = $('.output-mode-selection').val();
  $('.translation-details-row, .translation-details-help').toggle(outputMode === 'both' || outputMode === 'en');
}

function updateHebrewOptionsVisibility() {
  var outputMode = $('.output-mode-selection').val();
  $('.hebrew-options-row').toggle(outputMode !== 'en');
}

function updateVersionControlsVisibility() {
  var outputMode = $('.output-mode-selection').val();
  var hideTranslations = $('.translation-version-select option:not(:disabled)').length <= 1;
  $('.translation-version-control').toggle(outputMode !== 'he' && appMode !== 'voices' && !hideTranslations);
  $('.advanced-version-details').toggle(outputMode !== 'en' && appMode === 'advanced');
  $('.versions-section').toggleClass('single-translation', hideTranslations);
  if (appMode !== 'voices' && !!selectedResultKey) {
    $('.versions-section').toggle(!hideTranslations);
  }
}

function updateTransliterationVisibility() {
  var outputMode = $('.output-mode-selection').val();
  $('.transliteration-row, .transliteration-help, .transliteration-options-row').toggle(outputMode !== 'en');
}


function updateInsertionModeVisibility() {
  $('.insert-citation-help').show();
}

function normalizeOptionText(value) {
  return String(value || '')
    .replace(/&nbsp;/gi, ' ')
    .replace(/<[^>]*>/g, '')
    .replace(/[\u200B-\u200D\uFEFF\u200E\u200F\u202A-\u202E]/g, '')
    .replace(/^[\s\-–—:•·]+/, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function showInsertWarning(message) {
  var warningText = String(message || 'Could not insert at the current selection. Place the cursor where you want the source inserted, then try again.').trim();
  $('.insert-warning').remove();
  $('.suggestions').prepend("<div class='insert-warning' role='alert' aria-live='assertive'>" + escapeHTML(warningText) + "</div>");
}

function buildSefariaOpenUrl() {
  if (!data || !data.ref) {
    return '';
  }
  var refSlug = encodeURIComponent(data.ref).replace(/%20/g, '_');
  var params = new URLSearchParams();
  var outputMode = $('.output-mode-selection').val();
  if (outputMode === 'he') params.set('lang', 'he');
  else if (outputMode === 'en') params.set('lang', 'en');
  else params.set('lang', 'bi');

  var selectedTranslationVersion = $('.translation-version-select').val() || data.versionTitle || '';
  var selectedSourceVersion = $('.he-version-selection').val() || data.heVersionTitle || '';
  if (outputMode !== 'he' && selectedTranslationVersion) params.set('ven', selectedTranslationVersion);
  if (outputMode !== 'en' && selectedSourceVersion) params.set('vhe', selectedSourceVersion);

  var query = params.toString();
  return query ? "https://www.sefaria.org/" + refSlug + "?" + query : "https://www.sefaria.org/" + refSlug;
}

function normalizeUnifiedReferenceInput(value) {
  var normalized = String(value || '').trim();
  if (!normalized) return '';
  normalized = normalized
    .replace(/[־‐-―]/g, '-')
    .replace(/[“”„‟″״]/g, '"')
    .replace(/[‘’‚‛′׳]/g, "'")
    .replace(/[‎‏‪-‮]/g, '')
    .replace(/׃/g, ':')
    .replace(/\s*[:：]\s*/g, ':')
    .replace(/\s*[-–—]\s*/g, '-')
    .replace(/([֐-׿])["'׳״]+(?=[\s:.-]|$)/g, '$1')
    .replace(/([֐-׿])["'׳״]+(?=[֐-׿])/g, '$1')
    .replace(/\s+/g, ' ')
    .trim();
  return normalized;
}

function isLikelyHebrewScriptInput(value) {
  var normalized = String(value || '').trim();
  return /[\u0590-\u05FF]/.test(normalized) && !/[A-Za-z]/.test(normalized);
}

function normalizeLatinLookupTitleCase(value) {
  var input = String(value || '').trim();
  if (!input || !/[A-Za-z]/.test(input) || /[\u0590-\u05FF]/.test(input) || !Array.isArray(titles)) {
    return input;
  }

  var lowerInput = input.toLowerCase();
  var bestMatch = '';
  var bestMatchLength = 0;

  titles.forEach(function (title) {
    var candidate = String(title || '').trim();
    if (!candidate || !/[A-Za-z]/.test(candidate)) return;
    var lowerCandidate = candidate.toLowerCase();
    if (lowerInput !== lowerCandidate && lowerInput.indexOf(lowerCandidate + " ") !== 0 && lowerInput.indexOf(lowerCandidate + ":") !== 0) {
      return;
    }
    if (candidate.length > bestMatchLength) {
      bestMatch = candidate;
      bestMatchLength = candidate.length;
    }
  });

  if (!bestMatch) return input;
  return bestMatch + input.slice(bestMatchLength);
}

function mapSefariaRefSlugToLookupRef(slug) {
  var decoded = String(slug || '').trim();
  if (!decoded) return '';
  try {
    decoded = decodeURIComponent(decoded);
  } catch (error) {}
  decoded = decoded.replace(/^\/+/, '').replace(/\/+?/g, '/').replace(/_/g, ' ');
  decoded = decoded.replace(/\/+$/g, '').replace(/\/+/g, '/');
  var parts = decoded.split('/').filter(Boolean);
  if (!parts.length) return '';
  var titlePart = parts[0];
  var sectionPart = parts.slice(1).join(':');
  return sectionPart ? titlePart + " " + sectionPart : titlePart;
}

function parseSefariaUrlInput(inputValue) {
  var raw = String(inputValue || '').trim();
  if (!raw) return null;

  var parsedUrl;
  try {
    parsedUrl = new URL(raw);
  } catch (error) {
    return null;
  }

  var host = (parsedUrl.hostname || '').toLowerCase();
  if (host.indexOf('sefaria.org') < 0) return null;

  var path = (parsedUrl.pathname || '').replace(/^\/+/, '');
  if (!path) return null;

  var blockedRoots = { api: true, texts: true, sheets: true, topics: true, collections: true, account: true, profile: true, help: true };
  var slug = path.split('/')[0] || '';
  if (!slug || blockedRoots[slug.toLowerCase()]) return null;

  var ref = mapSefariaRefSlugToLookupRef(path);
  if (!ref) return null;

  var lang = (parsedUrl.searchParams.get('lang') || '').toLowerCase().trim();
  var outputMode = 'both';
  if (lang === 'en') outputMode = 'en';
  else if (lang === 'he') outputMode = 'he';

  return {
    ref: ref,
    outputMode: outputMode,
    preferredVersions: {
      en: parsedUrl.searchParams.get('ven') || '',
      he: parsedUrl.searchParams.get('vhe') || ''
    }
  };
}

function updateActionabilityUI(state) {
  var isActionable = !!(state && state.isInsertable);
  $('.display-layout-shell, .display-layout-section, .options-panel, .versions-section').toggleClass('section-muted', !isActionable);
}

function syncDisplayModeCards() {
  var outputMode = $('.output-mode-selection').val();
  $('.mode-card').each(function () {
    var isSelected = $(this).attr('data-mode') === outputMode;
    $(this).toggleClass('selected', isSelected);
    $(this).attr('aria-checked', isSelected ? 'true' : 'false');
  });
}

function syncLayoutCards() {
  var selectedLayout = $('.bilingual-layout-selection').val();
  $('.layout-option').each(function () {
    var isSelected = $(this).attr('data-layout') === selectedLayout;
    $(this).toggleClass('selected', isSelected);
    $(this).attr('aria-pressed', isSelected ? 'true' : 'false');
  });
}

function isResolvedReference(response) {
  return !!(response && response.ref && response.indexTitle && !response.error);
}

function hasRenderableText(value) {
  if (Array.isArray(value)) return value.some(function (part) { return hasRenderableText(part); });
  if (value === null || value === undefined) return false;
  var stripped = String(value).replace(/<[^>]*>/g, '').replace(/&nbsp;/gi, ' ').trim();
  return stripped.length > 0;
}

function buildDepthPrompt(response) {
  var sectionNames = (response && Array.isArray(response.sectionNames)) ? response.sectionNames.filter(Boolean) : [];
  if (sectionNames.length >= 2) return "Enter " + sectionNames[0] + " and optionally a " + sectionNames[1] + ". Specify a range with '-'.";
  if (sectionNames.length === 1) return "Enter " + sectionNames[0] + ". Specify a range with '-'.";
  return "Enter a valid reference to insert.";
}

function getResolvedNodeState(response) {
  var resolved = isResolvedReference(response);
  var hasText = hasRenderableText(response && response.text);
  var hasHebrew = hasRenderableText(response && response.he);
  var isInsertable = resolved && (hasText || hasHebrew);
  var isStructural = resolved && !isInsertable;
  return {
    resolved: resolved,
    hasText: hasText,
    hasHebrew: hasHebrew,
    isInsertable: isInsertable,
    isStructural: isStructural,
    prompt: buildDepthPrompt(response)
  };
}

function formatBreadcrumb(refValue) {
  var ref = String(refValue || '').trim();
  if (!ref) return '';
  var commaParts = ref.split(',').map(function (part) { return part.trim(); }).filter(Boolean);
  if (commaParts.length <= 1) return ref;
  var title = commaParts[0];
  var pathPart = commaParts.slice(1).join(', ');
  var pathPieces = pathPart.split(':').map(function (part) { return part.trim(); }).filter(Boolean);
  if (!pathPieces.length) return ref;
  return [title].concat(pathPieces).join(' › ');
}

function buildPreviewMeta(primaryRef, fallbackRef) {
  var breadcrumb = formatBreadcrumb(primaryRef);
  if (!breadcrumb && fallbackRef && fallbackRef.indexTitle && Array.isArray(fallbackRef.sections)) {
    breadcrumb = [fallbackRef.indexTitle].concat(fallbackRef.sections).join(' › ');
  }
  var fallback = '';
  if (typeof fallbackRef === 'string') fallback = fallbackRef.trim();
  else if (fallbackRef && typeof fallbackRef === 'object') fallback = String(fallbackRef.ref || fallbackRef.heRef || primaryRef || '').trim();
  else fallback = String(primaryRef || '').trim();
  var display = breadcrumb || fallback;
  return "<div class='preview-meta'>" + escapeHTML(display) + "</div>";
}

function buildNonInsertableMessage(response) {
  var state = getResolvedNodeState(response);
  return buildPreviewMeta(response && (response.ref || response.heRef), response || '') +
    "<div class='noninsertable-warning'><h4 class='preview-state-title'>This is a section, not a directly insertable text.</h4><p class='preview-state-message'>Choose a subsection or more specific reference to preview and insert.</p><p class='preview-state-message'>" +
    escapeHTML(state.prompt) + "</p></div>";
}

function clearVersionSelectors() {
  $('.translation-version-control').empty();
  $('.hebrew-version-control').empty();
}

function setResultsHint(message, allowHtml) {
  var text = String(message || '').trim();
  var $hint = $('.results-hint');
  if (!text) {
    $hint.hide().empty();
    return;
  }
  if (allowHtml) {
    $hint.html(message).show();
  } else {
    $hint.text(text).show();
  }
}

function setResultsLoading(isLoading) {
  resultsLoading = !!isLoading;
  $('.results-panel').toggleClass('is-loading', resultsLoading);
  if (!$('.results-loading-indicator').length) {
    $('.results-header').append("<div class='results-loading-indicator' aria-live='polite' style='display:none;'><span class='preview-loading-spinner' aria-hidden='true'></span><span>Searching…</span></div>");
  }
  $('.results-loading-indicator').toggle(resultsLoading);
}

function normalizeFuzzyText(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/[֑-ׇ]/g, '')
    .replace(/[_.,/#!$%^&*;:{}=\\\-`~()\[\]"'׳״]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function splitReferenceForFuzzy(query) {
  var raw = String(query || '').trim();
  if (!raw) return { titlePart: '', suffixPart: '' };
  var match = raw.match(/^(.*?)(\s+[\d\u05D0-\u05EA].*)$/);
  if (!match) return { titlePart: raw, suffixPart: '' };
  return { titlePart: String(match[1] || '').trim(), suffixPart: String(match[2] || '') };
}

function levenshteinDistance(a, b) {
  a = String(a || '');
  b = String(b || '');
  if (!a) return b.length;
  if (!b) return a.length;
  var matrix = [];
  for (var i = 0; i <= b.length; i++) matrix[i] = [i];
  for (var j = 0; j <= a.length; j++) matrix[0][j] = j;
  for (i = 1; i <= b.length; i++) {
    for (j = 1; j <= a.length; j++) {
      var cost = a.charAt(j - 1) === b.charAt(i - 1) ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,
        matrix[i][j - 1] + 1,
        matrix[i - 1][j - 1] + cost
      );
    }
  }
  return matrix[b.length][a.length];
}

function getFuzzyReferenceSuggestions(query) {
  var split = splitReferenceForFuzzy(query);
  var titlePart = normalizeFuzzyText(split.titlePart);
  if (!titlePart || titlePart.length < 2 || !Array.isArray(titles) || !titles.length) return [];
  var queryLooksHebrew = isLikelyHebrewScriptInput(split.titlePart);
  var firstChar = titlePart.charAt(0);
  var scored = titles.map(function (title) {
    var rawTitle = String(title || '').trim();
    var normalizedTitle = normalizeFuzzyText(rawTitle);
    if (!normalizedTitle) return null;
    var titleIsHebrew = isLikelyHebrewScriptInput(rawTitle);
    if (queryLooksHebrew !== titleIsHebrew) return null;
    if (firstChar && normalizedTitle.charAt(0) !== firstChar && normalizedTitle.indexOf(titlePart) !== 0 && titlePart.indexOf(normalizedTitle) !== 0) return null;
    var distance = levenshteinDistance(titlePart, normalizedTitle);
    var maxLen = Math.max(titlePart.length, normalizedTitle.length, 1);
    var ratio = distance / maxLen;
    var startsBonus = normalizedTitle.indexOf(titlePart) === 0 ? -0.25 : 0;
    var containsBonus = normalizedTitle.indexOf(titlePart) >= 0 ? -0.15 : 0;
    var score = ratio + startsBonus + containsBonus;
    if (ratio > 0.55 && normalizedTitle.indexOf(titlePart) < 0 && titlePart.indexOf(normalizedTitle) < 0) return null;
    return { rawTitle: rawTitle, score: score };
  }).filter(Boolean).sort(function (a, b) {
    if (a.score !== b.score) return a.score - b.score;
    return a.rawTitle.localeCompare(b.rawTitle);
  });

  var seen = {};
  return scored.filter(function (entry) {
    var suggestion = entry.rawTitle + split.suffixPart;
    if (seen[suggestion]) return false;
    seen[suggestion] = true;
    return suggestion.toLowerCase() !== String(query || '').trim().toLowerCase();
  }).slice(0, MAX_FUZZY_SUGGESTIONS).map(function (entry) {
    return entry.rawTitle + split.suffixPart;
  });
}

function renderFuzzySuggestions(query) {
  var suggestions = getFuzzyReferenceSuggestions(query);
  if (!suggestions.length) return;
  var html = "<div class='results-suggestion-wrap'><div class='results-suggestion-title'>Did you mean</div><div class='results-suggestion-buttons'>" + suggestions.map(function (suggestion) {
    return "<button type='button' class='results-suggestion-button' data-suggested-query='" + escapeHTML(suggestion) + "'>" + escapeHTML(suggestion) + "</button>";
  }).join('') + "</div></div>";
  setResultsHint(html, true);
}

function maybeShowZeroResultsSuggestions(input) {
  var hasRawResults = getAllRawResults().length > 0;
  var currentHint = $.trim($('.results-hint').text());
  if (!hasRawResults && !currentHint) {
    renderFuzzySuggestions(input);
  }
}

function describeResultLanguages(item) {
  var available = Array.isArray(item && item.availableLangs) ? item.availableLangs : [];
  var unique = [];
  available.forEach(function (lang) {
    var normalized = String(lang || '').toLowerCase().trim();
    if (normalized && unique.indexOf(normalized) < 0) unique.push(normalized);
  });
  if (unique.length === 1) {
    var singleMap = { en: 'EN', he: 'HE', es: 'ES', fr: 'FR', de: 'DE', ru: 'RU', ar: 'AR', pt: 'PT', it: 'IT' };
    return singleMap[unique[0]] || unique[0].toUpperCase();
  }
  if (!unique.length) return 'Single version';
  var labelMap = { en: 'EN', he: 'HE', es: 'ES', fr: 'FR', de: 'DE', ru: 'RU', ar: 'AR', pt: 'PT', it: 'IT' };
  return unique.map(function (lang) { return labelMap[lang] || lang.toUpperCase(); }).join(', ');
}

function getCorpusAccentClass(corpusKey) {
  return corpusColorClassMap[String(corpusKey || '').toLowerCase()] || 'corpus-accent-default';
}


function getCheckedValues(selector) {
  return $(selector).map(function () {
    return $(this).is(':checked') ? $(this).val() : null;
  }).get().filter(Boolean);
}

function updateMultiSelectButtonLabel(dropdownSelector, values, fallbackText, labelMap) {
  labelMap = labelMap || null;
  var labels = values.map(function (value) {
    return labelMap && labelMap[value] ? labelMap[value] : value;
  });
  var text = labels.length ? labels.join(', ') : fallbackText;
  $(dropdownSelector + ' .multi-select-button-text').text(text);
}


function syncCompactTranslationLanguageUI() {
  var selected = getCheckedValues('.translation-language-option');
  var anySelected = !selected.length || $('.translation-language-any').is(':checked');
  var labelMap = { en: 'EN', he: 'HE', es: 'ES', fr: 'FR', de: 'DE', pt: 'PT', ru: 'RU', ar: 'AR', it: 'IT' };
  var label = 'Any';
  if (!anySelected && selected.length) {
    label = selected.slice(0, 2).map(function(lang){ return labelMap[lang] || String(lang || '').toUpperCase(); }).join(', ');
    if (selected.length > 2) label += ' +' + (selected.length - 2);
  }
  $('#translation-language-toggle').html(
    '<span class="latin-part" aria-hidden="true">A</span>' +
    '<span class="alef-part" aria-hidden="true">א</span>' +
    '<span class="translation-language-button-label">' + escapeHTML(label) + '</span>'
  );
}

function updateTranslationLanguageVisibility() {
  var selectedValues = getCheckedValues('.translation-language-option');
  var useAny = $('.translation-language-any').is(':checked') || !selectedValues.length;

  if (useAny) {
    $('.translation-language-any').prop('checked', true);
    $('.translation-language-option').prop('checked', false);
    $('.translation-only-filter').prop('checked', false);
  } else {
    $('.translation-language-any').prop('checked', false);
    $('.translation-only-filter').prop('checked', true);
  }

  syncCompactTranslationLanguageUI();
}

function getSearchParameters() {
  var sortMode = $('#search-sort-mode').length ? ($('#search-sort-mode').val() || 'relevance') : 'relevance';
  var selectedLanguages = getCheckedValues('.translation-language-option');
  var anySelected = $('.translation-language-any').is(':checked') || !selectedLanguages.length;
  return {
    filters: [],
    relevanceSort: sortMode === 'relevance',
    sortMode: sortMode,
    translationOnly: !anySelected,
    translationLanguages: anySelected ? [] : selectedLanguages
  };
}

function updateQueryIntel(input) { return; }






var sessionLibrary = { pinned: [], inserted: [] };
var sessionLibraryFilter = 'all';

function loadSessionLibrary() {
  try {
    sessionLibrary = JSON.parse(localStorage.getItem('sefariaSidebarSessionLibrary') || '{"pinned":[],"inserted":[]}');
    if (!sessionLibrary || typeof sessionLibrary !== 'object') throw new Error('bad');
    if (!Array.isArray(sessionLibrary.pinned)) sessionLibrary.pinned = [];
    if (!Array.isArray(sessionLibrary.inserted)) sessionLibrary.inserted = [];
  } catch (e) {
    sessionLibrary = { pinned: [], inserted: [] };
  }
}

function saveSessionLibrary() {
  try { localStorage.setItem('sefariaSidebarSessionLibrary', JSON.stringify(sessionLibrary)); } catch (e) {}
}

function buildSessionEntry(ref, label, corpusLabel) {
  var rawLabel = String(label || ref || '').split(' › ')[0].split(',')[0].trim();
  return { ref: ref, label: rawLabel || ref, corpusLabel: String(corpusLabel || 'Other') };
}

function upsertSessionEntry(listName, entry) {
  if (!entry || !entry.ref) return;
  var list = sessionLibrary[listName] || [];
  list = list.filter(function(item){ return item && item.ref !== entry.ref; });
  list.unshift(entry);
  sessionLibrary[listName] = list.slice(0, 12);
  saveSessionLibrary();
  renderSessionLibrary();
}

function removeSessionEntry(listName, ref) {
  sessionLibrary[listName] = (sessionLibrary[listName] || []).filter(function(item){ return item && item.ref !== ref; });
  saveSessionLibrary();
  renderSessionLibrary();
}


function getCurrentCorpusForRef(ref) {
  var allItems = getAllProcessedResults().concat(getAllRawResults());
  var match = allItems.find(function(item){ return item && item.ref === ref; });
  return match ? getResultCorpusLabel(match, 'Other') : 'Other';
}

function isPinnedRef(ref) {
  return (sessionLibrary.pinned || []).some(function(item){ return item && item.ref === ref; });
}

function togglePinnedRef(ref, label) {
  if (!ref) return;
  if (isPinnedRef(ref)) removeSessionEntry('pinned', ref);
  else upsertSessionEntry('pinned', buildSessionEntry(ref, label, getCurrentCorpusForRef(ref)));
  renderResults();
}

function resetResultPostProcessState() {
  resultPostProcessState = { availableCorpora: [], removedCorpora: [] };
}

function getAllProcessedResults() {
  return queryState.libraryMatches.concat(queryState.searchResults).filter(function (item) { return item && item.ref; });
}

function getAllRawResults() {
  return queryState.rawLibraryMatches.concat(queryState.rawSearchResults).filter(function (item) { return item && item.ref; });
}

function getResultCorpusLabel(item, fallbackLabel) {
  return String((item && (item.clusterLabel || item.typeLabel || fallbackLabel)) || 'Other').trim() || 'Other';
}

function getResultCorpusKey(item, fallbackLabel) {
  return getResultCorpusLabel(item, fallbackLabel)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '') || 'other';
}

function syncAvailableCorpusFilters() {
  var seen = {};
  resultPostProcessState.availableCorpora = getAllRawResults().map(function (item) {
    return {
      key: getResultCorpusKey(item, 'Results'),
      label: getResultCorpusLabel(item, 'Results')
    };
  }).filter(function (entry) {
    if (!entry.key || seen[entry.key]) return false;
    seen[entry.key] = true;
    return true;
  });
  resultPostProcessState.removedCorpora = resultPostProcessState.removedCorpora.filter(function (key) {
    return resultPostProcessState.availableCorpora.some(function (entry) { return entry.key === key; });
  });
}

function ensureResultFilterUI() {
  if ($('.result-filter-strip').length) {
    return;
  }
  $('.results-header').after("<div class='result-filter-strip' style='display:none;'></div>");
}

function renderResultFilterStrip() {
  ensureResultFilterUI();
  var $strip = $('.result-filter-strip');
  $strip.hide().empty();
  var $wrap = $('#restore-corpus-wrap');
  var $select = $('#restore-corpus-select');
  if (!$wrap.length || !$select.length) return;
  var removed = resultPostProcessState.removedCorpora.slice();
  if (!removed.length) {
    $wrap.hide();
    $select.html('<option value="">Restore…</option>').val('');
    return;
  }
  var options = ['<option value="">Restore…</option>'];
  removed.forEach(function (key) {
    var entry = resultPostProcessState.availableCorpora.find(function (item) { return item.key === key; });
    options.push('<option value="' + escapeHTML(key) + '">' + escapeHTML(entry ? entry.label : key) + '</option>');
  });
  $select.html(options.join(''));
  $wrap.show();
}

function resetSelectedResultView() {
  selectedResultKey = null;
  selectedResultSummary = null;
  selectedRefValue = null;
  resultsCollapsed = false;
  hasResolvedReference = false;
  setInsertButtonState(false);
  $('#open-on-sefaria').prop('disabled', true);
  data = {};
  clearVersionSelectors();
  updatePesukimAvailability(null);
  $('.result-item').removeClass('selected').attr('aria-pressed', 'false');
  $('.suggestions').html("<b>Select a result to preview it.</b>");
  updateActionabilityUI({ isInsertable: false });
}

function ensureSelectedResultStillVisible() {
  if (!selectedResultKey) {
    return;
  }
  var stillVisible = getAllProcessedResults().some(function (item) { return item.key === selectedResultKey; });
  if (!stillVisible) {
    resetSelectedResultView();
  }
}

function applyResultPostProcessing() {
  syncAvailableCorpusFilters();
  var removedLookup = {};
  resultPostProcessState.removedCorpora.forEach(function (key) {
    removedLookup[key] = true;
  });
  var searchParameters = getSearchParameters();
  var filterItems = function (items, fallbackLabel) {
    return applyClientSideSearchFilters(items, searchParameters).filter(function (item) {
      return !removedLookup[getResultCorpusKey(item, fallbackLabel)];
    });
  };

  queryState.libraryMatches = sortLibraryItems(
    dedupeResultItems(filterItems(queryState.rawLibraryMatches, 'Library matches')),
    searchParameters.sortMode
  );
  queryState.searchResults = sortSearchItems(
    dedupeResultItems(filterItems(queryState.rawSearchResults, 'Search results')),
    searchParameters.sortMode
  );
  ensureSelectedResultStillVisible();
  renderResultFilterStrip();
  setResultsLoading(false);
}


function reprocessAndRenderResults() {
  applyResultPostProcessing();
  renderResults();
}

function toggleCorpusVisibility(corpusKey) {
  var existingIndex = resultPostProcessState.removedCorpora.indexOf(corpusKey);
  if (existingIndex >= 0) {
    resultPostProcessState.removedCorpora.splice(existingIndex, 1);
  } else {
    resultPostProcessState.removedCorpora.push(corpusKey);
  }
  reprocessAndRenderResults();
}

function renderResultGroup(selector, items, groupName) {
  var $list = $(selector);
  $list.empty();
  if (!items.length) {
    if (selector === '.search-results') return;
    $list.append("<li class='result-subtitle'>No " + groupName.toLowerCase() + ".</li>");
    return;
  }

  var lastCluster = '';
  items.forEach(function (item) {
    var cluster = getResultCorpusLabel(item, groupName);
    var corpusKey = getResultCorpusKey(item, groupName);
    var accentClass = getCorpusAccentClass(corpusKey);
    if (cluster && cluster !== lastCluster) {
      $list.append("<li class='result-group-header " + accentClass + "'><button type='button' class='result-group-remove' data-corpus-key='" + escapeHTML(corpusKey) + "' title='Hide corpus'>❌</button><span class='result-cluster-label'>" + escapeHTML(cluster) + "</span></li>");
      lastCluster = cluster;
    }
    var selectedClass = item.key === selectedResultKey ? 'selected' : '';
    var metaLine = "<div class='result-meta'><span>" + escapeHTML(cluster) + "</span><span> • </span><span>" + escapeHTML(describeResultLanguages(item)) + "</span></div>";
    var subtitle = item.subtitle ? "<div class='result-subtitle'>" + escapeHTML(item.subtitle) + "</div>" : '';
    var snippet = item.snippet ? "<div class='result-snippet'>" + item.snippet + "</div>" : subtitle;
    var titleText = appMode === 'voices' ? (item.label || item.ref) : (groupName === 'Search results' && item.ref ? item.ref : (item.label || item.ref));
    $list.append("<li class='result-item result-row " + accentClass + " " + selectedClass + "' data-key='" + escapeHTML(item.key) + "' data-ref='" + escapeHTML(item.ref) + "' role='button' tabindex='0' aria-pressed='" + (item.key === selectedResultKey ? 'true' : 'false') + "'><div class='result-row-main'><button type='button' class='result-pin-button' data-ref='" + escapeHTML(item.ref) + "' data-label='" + escapeHTML(titleText) + "' aria-label='" + (isPinnedRef(item.ref) ? "Unpin result" : "Pin result") + "' title='" + (isPinnedRef(item.ref) ? "Unpin result" : "Pin result") + "'>📌</button><div class='result-title'>" + escapeHTML(titleText) + "</div></div>" + metaLine + snippet + "</li>");
  });
}


function renderResults() {
  renderResultGroup('.library-results', queryState.libraryMatches, 'Library matches');
  renderResultGroup('.search-results', queryState.searchResults, 'Search results');

  var hasLibraryMatches = queryState.libraryMatches.length > 0;
  var hasSearchResults = queryState.searchResults.length > 0;

  $('.library-results-heading-row').toggle(appMode !== 'voices' && hasLibraryMatches);
  $('.restore-corpus-row').toggle(appMode !== 'voices' && hasLibraryMatches && resultPostProcessState.removedCorpora.length > 0);
  $('.search-results-label').toggle(appMode !== 'voices' && hasSearchResults);
  $('.search-results').toggle(appMode === 'voices' || hasSearchResults);

  updateResultsVisibility();
}

function updateResultsVisibility() {
  var shouldCollapse = resultsCollapsed && !!selectedResultSummary;
  $('.results-lists').toggle(!shouldCollapse);
  $('.results-toggle-button').toggle(!!selectedResultSummary).text(shouldCollapse ? 'Show results' : 'Hide results');
  if (shouldCollapse) {
    $('.selected-result-summary').html("<strong>" + escapeHTML(selectedResultSummary.label) + "</strong>" + (selectedResultSummary.subtitle ? "<div>" + escapeHTML(selectedResultSummary.subtitle) + "</div>" : '') + (selectedResultSummary.status ? "<div class='helper-text'>" + escapeHTML(selectedResultSummary.status) + "</div>" : '')).show();
  } else {
    $('.selected-result-summary').hide().empty();
  }
}

function clearSelectedResult() {
  resetResultPostProcessState();
  queryState = { rawLibraryMatches: [], rawSearchResults: [], libraryMatches: [], searchResults: [] };
  resetSelectedResultView();
  updateResultsVisibility();
  renderResultFilterStrip();
}

function compareResultsAlphabetically(a, b, direction) {
  var left = normalizeOptionText((a && (a.label || a.ref)) || '').toLowerCase();
  var right = normalizeOptionText((b && (b.label || b.ref)) || '').toLowerCase();
  return direction === 'desc' ? right.localeCompare(left) : left.localeCompare(right);
}

function isDirectReferenceItem(item) {
  if (!item) return false;
  var subtitle = String(item.subtitle || '').toLowerCase();
  var key = String(item.key || '').toLowerCase();
  return subtitle.indexOf('direct reference lookup') >= 0 || key.indexOf('library-ref-') === 0;
}

function sortLibraryItems(items, sortMode) {
  var direct = [];
  var rest = [];
  (items || []).forEach(function(item) {
    (isDirectReferenceItem(item) ? direct : rest).push(item);
  });
  if (sortMode === 'alphabetical-asc') {
    rest.sort(function(a, b) { return compareResultsAlphabetically(a, b, 'asc'); });
  } else if (sortMode === 'alphabetical-desc') {
    rest.sort(function(a, b) { return compareResultsAlphabetically(a, b, 'desc'); });
  }
  return direct.concat(rest);
}

function sortSearchItems(items, sortMode) {
  var out = (items || []).slice();
  if (sortMode === 'alphabetical-asc') {
    out.sort(function(a, b) { return compareResultsAlphabetically(a, b, 'asc'); });
  } else if (sortMode === 'alphabetical-desc') {
    out.sort(function(a, b) { return compareResultsAlphabetically(a, b, 'desc'); });
  }
  return out;
}

function itemMatchesTranslationLanguages(item, languages) {
  if (!item || item.hasTranslation === false) return false;
  var selected = Array.isArray(languages) ? languages.filter(Boolean) : [];
  if (!selected.length) return item.hasTranslation !== false;
  var available = Array.isArray(item.availableLangs) ? item.availableLangs.map(function (lang) { return String(lang || '').toLowerCase(); }) : [];
  if (!available.length) return item.hasTranslation !== false;
  return selected.some(function (lang) { return available.indexOf(String(lang || '').toLowerCase()) >= 0; });
}

function dedupeResultItems(items) {
  var seen = {};
  var out = [];
  (items || []).forEach(function(item) {
    if (!item || !item.ref) return;
    var key = String(item.ref).trim().toLowerCase();
    if (seen[key]) return;
    seen[key] = true;
    out.push(item);
  });
  return out;
}

function applyClientSideSearchFilters(items, searchParameters) {
  var filtered = Array.isArray(items) ? items.slice() : [];
  if (searchParameters && searchParameters.translationOnly) {
    filtered = filtered.filter(function (item) { return itemMatchesTranslationLanguages(item, searchParameters.translationLanguages); });
  }
  return filtered;
}

function maybeAutoSelectSingleResult() {
  var allResults = queryState.libraryMatches.concat(queryState.searchResults).filter(function (item) { return item && item.ref; });
  if (allResults.length !== 1) return;
  var only = allResults[0];
  if (!only || !only.key || selectedResultKey === only.key) return;
  selectedResultKey = only.key;
  selectedResultSummary = { label: only.label || only.ref, subtitle: only.subtitle || '' };
  resultsCollapsed = true;
  renderResults();
  resolveSelectedResult(only.ref, only.label || only.ref);
}

function formatRefForResult(ref) {
  var clean = String(ref || '').trim();
  var chunks = clean.split(',').map(function (part) { return part.trim(); }).filter(Boolean);
  if (chunks.length <= 1) return { label: clean, subtitle: '' };
  return { label: chunks[0], subtitle: chunks.slice(1).join(' › ') };
}

function buildResultFromSource(source, fallbackRef, keyPrefix, index, snippet, typeLabel) {
  var ref = source.ref || fallbackRef || '';
  var display = formatRefForResult(ref);
  var sourcePath = Array.isArray(source.path) ? source.path.filter(Boolean) : (typeof source.path === 'string' ? source.path.split('/').map(function (part) { return part.trim(); }).filter(Boolean) : []);
  var breadcrumb = sourcePath.length > 1 ? sourcePath.slice(0, -1).join(' › ') : (display.subtitle || source.heRef || '');
  var availableLangs = Array.isArray(source && source.availableLangs) ? source.availableLangs.map(function (lang) { return String(lang || '').toLowerCase(); }).filter(Boolean) : (Array.isArray(source && source.versions) ? source.versions.map(function (version) { return String((version && version.language) || '').toLowerCase(); }).filter(Boolean) : []);
  var clusterLabel = source.primary_category || (Array.isArray(source.categories) ? source.categories[0] : '') || typeLabel;

  return {
    key: keyPrefix + "-" + index + "-" + (ref || index),
    ref: ref,
    label: sourcePath[sourcePath.length - 1] || display.label || ref || 'Result',
    subtitle: breadcrumb,
    snippet: snippet,
    typeLabel: typeLabel,
    clusterLabel: clusterLabel,
    availableLangs: availableLangs,
    hasTranslation: source && (Array.isArray(source.availableLangs) ? source.availableLangs.length > 0 : (Array.isArray(source.versions) ? source.versions.some(function (version) { return version && String(version.language || '').trim(); }) : true))
  };
}

function runUnifiedQuery() {
  var input = normalizeUnifiedReferenceInput(($('.input').val() || '').trim());
  $('.input').val(input);
  clearSelectedResult();
  setResultsHint('');
  setResultsLoading(true);
  pendingPreferredVersions = null;

  if (!input) {
    queryState = { rawLibraryMatches: [], rawSearchResults: [], libraryMatches: [], searchResults: [] };
    resetResultPostProcessState();
    reprocessAndRenderResults();
    updateActionabilityUI({ isInsertable: false });
    $('.suggestions').html("<b>Please enter a reference, title, or phrase.</b>");
    setResultsLoading(false);
    return;
  }

  var sefariaUrlInput = parseSefariaUrlInput(input);
  if (sefariaUrlInput) {
    $('.output-mode-selection').val(sefariaUrlInput.outputMode);
    syncDisplayModeCards();
    updateBilingualLayoutVisibility();
    updateTranslationDetailsVisibility();
    updateVersionControlsVisibility();

    pendingPreferredVersions = sefariaUrlInput.preferredVersions;
    resetResultPostProcessState();
    queryState.rawLibraryMatches = [{
      key: "library-ref-" + sefariaUrlInput.ref,
      ref: sefariaUrlInput.ref,
      label: sefariaUrlInput.ref,
      subtitle: 'Parsed from Sefaria URL',
      typeLabel: 'Library',
      hasTranslation: true,
      availableLangs: []
    }];
    queryState.rawSearchResults = [];
    reprocessAndRenderResults();

    selectedResultKey = queryState.libraryMatches[0].key;
    selectedResultSummary = { label: sefariaUrlInput.ref, subtitle: 'Parsed from Sefaria URL' };
    resultsCollapsed = true;
    updateResultsVisibility();
    setResultsLoading(false);
    resolveSelectedResult(sefariaUrlInput.ref, sefariaUrlInput.ref);
    return;
  }

  var prefixTitles = titles
    .filter(function (title) { return title && title.toUpperCase().indexOf(input.toUpperCase()) === 0; })
    .slice(0, 6)
    .map(function (title, index) {
      return {
        key: "library-title-" + index + "-" + title,
        ref: title,
        label: title,
        subtitle: 'Title match',
        typeLabel: 'Library',
        hasTranslation: true,
        availableLangs: []
      };
    });

  var directLookupInput = normalizeLatinLookupTitleCase(input);
  var directRefMatch = {
    key: "library-ref-" + directLookupInput,
    ref: directLookupInput,
    label: input,
    subtitle: 'Direct reference lookup',
    typeLabel: 'Library',
    hasTranslation: true,
    availableLangs: []
  };

  var isHebrewScript = isLikelyHebrewScriptInput(input);
  resetResultPostProcessState();
  queryState.rawLibraryMatches = prefixTitles;
  queryState.rawSearchResults = [];
  reprocessAndRenderResults();

  var requestId = ++latestQueryRequestId;
  var validationRequestId = ++latestDirectRefValidationRequestId;
  var pendingAsyncResultGroups = 2;
  function finishResultGroup() {
    if (requestId !== latestQueryRequestId) return;
    pendingAsyncResultGroups = Math.max(0, pendingAsyncResultGroups - 1);
    if (pendingAsyncResultGroups === 0) {
      setResultsLoading(false);
      maybeShowZeroResultsSuggestions(input);
      maybeAutoSelectSingleResult();
    }
  }

  google.script.run.withSuccessHandler(function (response) {
    if (validationRequestId !== latestDirectRefValidationRequestId || requestId !== latestQueryRequestId) return;
    var isValidDirectRef = getResolvedNodeState(response).resolved;
    if (isValidDirectRef) {
      queryState.rawLibraryMatches = [directRefMatch].concat(queryState.rawLibraryMatches).slice(0, 10);
      setResultsHint('');
    } else if (isHebrewScript) {
      setResultsHint('No direct library match for this Hebrew ref. Check spelling and try again.');
    }
    reprocessAndRenderResults();
    finishResultGroup();
  }).withFailureHandler(function () {
    if (validationRequestId !== latestDirectRefValidationRequestId || requestId !== latestQueryRequestId) return;
    if (isHebrewScript) setResultsHint('No direct library match for this Hebrew ref. Check spelling and try again.');
    finishResultGroup();
  }).findReference(directLookupInput);

  var searchParameters = getSearchParameters();
  google.script.run.withSuccessHandler(function (response) {
    if (requestId !== latestQueryRequestId) return;
    var hits = (Array.isArray(response) ? response : (((response || {}).hits || {}).hits || [])).slice(0, 24);
    var libraryPathHits = [];
    var contentHits = [];
    hits.forEach(function (hit, index) {
      var source = (hit && hit._source) ? hit._source : {};
      var snippet = hit && hit.highlight && hit.highlight.naive_lemmatizer && hit.highlight.naive_lemmatizer[0] ? hit.highlight.naive_lemmatizer[0] : '';
      var pathDepth = Array.isArray(source.path) ? source.path.filter(Boolean).length : (typeof source.path === 'string' ? source.path.split('/').filter(Boolean).length : 0);
      if (pathDepth > 1) {
        libraryPathHits.push(buildResultFromSource(source, source.ref, 'library-search', index, snippet, 'Library path'));
        return;
      }
      contentHits.push(buildResultFromSource(source, source.ref, 'search', index, snippet, 'Content hit'));
    });
    var filteredLibraryPathHits = applyClientSideSearchFilters(libraryPathHits, searchParameters).slice(0, 10);
    var filteredContentHits = applyClientSideSearchFilters(contentHits, searchParameters).slice(0, 12);
    queryState.rawLibraryMatches = queryState.rawLibraryMatches.concat(filteredLibraryPathHits).slice(0, 10);
    queryState.rawSearchResults = filteredContentHits;
    if (searchParameters.translationOnly && !queryState.libraryMatches.length && !queryState.searchResults.length) {
      setResultsHint('No results matched the selected translation language filter.');
    }
    reprocessAndRenderResults();
    finishResultGroup();
  }).withFailureHandler(function (error) {
    if (requestId !== latestQueryRequestId) return;
    queryState.rawSearchResults = [];
    if (error && error.message) setResultsHint(error.message);
    reprocessAndRenderResults();
    finishResultGroup();
  }).findSearchAdvanced(input, searchParameters);
}

function resolveSelectedResult(selectedRef, inputLabel) {
  selectedRefValue = selectedRef;
  var requestId = ++latestResolveRequestId;
  hasResolvedReference = false;
  setInsertButtonState(false);
  $('#open-on-sefaria').prop('disabled', true);
  updatePesukimAvailability(null);
  $('.suggestions').html(buildPreviewLoadingHTML('Loading preview…'));

  google.script.run.withSuccessHandler(function (response) {
    if (requestId !== latestResolveRequestId) return;
    var nodeState = getResolvedNodeState(response);
    if (nodeState.isInsertable) {
      if (selectedResultSummary) {
        selectedResultSummary.status = 'Ready to insert';
        updateResultsVisibility();
      }
      updateSuggestion(response, inputLabel);
      updatePesukimAvailability(response);
      updateActionabilityUI(nodeState);
      data = response;
      hasResolvedReference = true;
      setInsertButtonState(true);
      $('#open-on-sefaria').prop('disabled', false);
      return;
    }

    hasResolvedReference = false;
    setInsertButtonState(false);
    $('#open-on-sefaria').prop('disabled', true);
    if (selectedResultSummary) {
      selectedResultSummary.status = 'Choose a more specific ref';
      updateResultsVisibility();
    }
    clearVersionSelectors();
    updatePesukimAvailability(null);
    updateActionabilityUI(nodeState);
    $('.suggestions').html("<br>" + buildNonInsertableMessage(response));
  }).withFailureHandler(function () {
    if (requestId !== latestResolveRequestId) return;
    hasResolvedReference = false;
    setInsertButtonState(false);
    $('#open-on-sefaria').prop('disabled', true);
    clearVersionSelectors();
    updatePesukimAvailability(null);
    updateActionabilityUI({ isInsertable: false });
    $('.suggestions').html("<br><b>Enter a valid reference to insert.</b>");
  }).findReference(selectedRef);
}

function refreshSelectedResult() {
  if (!selectedRefValue) return;
  var fallbackLabel = selectedResultSummary && selectedResultSummary.label ? selectedResultSummary.label : selectedRefValue;
  resolveSelectedResult(selectedRefValue, fallbackLabel);
}

$('#insert-source').click(function () {
  if (!hasResolvedReference || !data || !data.ref) return;

  var outputMode = $('.output-mode-selection').val();
  var language = (outputMode === 'both') ? undefined : outputMode;
  var bilingualLayout = $('.bilingual-layout-selection').val();
  var showPesukim = Boolean($('.wants-pesukim').prop('checked'));
  var includeTranslationSourceInfo = $('.include-translation-source-info').is(':checked');
  var insertSefariaLink = $('.insert-sefaria-link').is(':checked');
  var input = $('.input').val();

  $('.hide').add($('.warning')).fadeIn('1000');
  google.script.run.withSuccessHandler(function () {
    $('.hide').add($('.warning')).fadeOut('1000');
    $('.insert-warning').remove();
    upsertSessionEntry('inserted', buildSessionEntry(data.ref, selectedResultSummary && selectedResultSummary.label ? selectedResultSummary.label : data.ref, getCurrentCorpusForRef(data.ref)));
    }).withFailureHandler(function (error) {
    $('.hide').add($('.warning')).fadeOut('1000');
    showInsertWarning(error && error.message);
  }).insertReference(
      data,
      language,
      showPesukim,
      input,
      includeTranslationSourceInfo,
      bilingualLayout,
      insertSefariaLink,
      $('.include-transliteration').is(':checked'),
      $('.insert-citation-only').is(':checked')
    );
});

$('#run-sefaria').off('click').on('click', runUnifiedQuery);

// Debounced unified search replaces legacy autocomplete dropdown.
$('.input').on('input', function () {
  var value = $(this).val() || '';
  updateQueryIntel(value);
  if (searchDebounceHandle) clearTimeout(searchDebounceHandle);
  searchDebounceHandle = setTimeout(function () {
    if ((value || '').trim().length >= 2) runUnifiedQuery();
  }, 320);
});

$('.input').on('keydown', function (event) {
  if (event.key === 'Enter') {
    event.preventDefault();
    if (keyboardResultIndex >= 0 && $('.result-item').length) {
      $('.result-item').eq(keyboardResultIndex).trigger('click');
      return;
    }
    runUnifiedQuery();
  }
  if (event.key === 'ArrowDown') {
    event.preventDefault();
    focusResultByIndex(keyboardResultIndex + 1);
  }
  if (event.key === 'ArrowUp') {
    event.preventDefault();
    focusResultByIndex(keyboardResultIndex <= 0 ? 0 : keyboardResultIndex - 1);
  }
});

$(document).on('keydown', function (event) {
  if (event.key === '/' && !$(event.target).is('input, textarea, select')) {
    event.preventDefault();
    $('.input').focus();
  }
});

$('.wants-relevance, .search-sort-select, .translation-only-filter').on('change', function () {
  updateTranslationLanguageVisibility();
  saveLastUsedSearchSettings();
  if (getAllRawResults().length) {
    reprocessAndRenderResults();
  } else if (($('.input').val() || '').trim()) {
    runUnifiedQuery();
  }
});

$('.results-panel').on('click keydown', '.result-item', function (event) {
  if (event.type === 'keydown' && event.key !== 'Enter' && event.key !== ' ') return;
  event.preventDefault();

  var key = $(this).attr('data-key');
  var item = queryState.libraryMatches.concat(queryState.searchResults).find(function (result) { return result.key === key; });
  if (!item) return;

  selectedResultKey = item.key;
  selectedResultSummary = { label: item.label || item.ref, subtitle: item.subtitle || '' };
  resultsCollapsed = true;
  $('.result-item').removeClass('selected').attr('aria-pressed', 'false');
  $(this).addClass('selected').attr('aria-pressed', 'true');
  updateResultsVisibility();
  resolveSelectedResult(item.ref, item.label || item.ref);
});

$('.results-panel').on('click', '.result-group-remove', function (event) {
  event.preventDefault();
  event.stopPropagation();
  var corpusKey = $(this).attr('data-corpus-key');
  if (!corpusKey) return;
  toggleCorpusVisibility(corpusKey);
});

$('.results-panel').on('click', '.result-filter-chip', function (event) {
  event.preventDefault();
  var corpusKey = $(this).attr('data-corpus-key');
  if (!corpusKey) return;
  toggleCorpusVisibility(corpusKey);
});

$('.results-toggle-button').on('click', function () {
  if (!selectedResultSummary) return;
  resultsCollapsed = !resultsCollapsed;
  updateResultsVisibility();
});


$('#open-on-sefaria').on('click', function () {
  var sefariaUrl = buildSefariaOpenUrl();
  if (!sefariaUrl) return;
  window.open(sefariaUrl, '_blank', 'noopener');
});

$('.open-divine-name-preferences, .open-preferences-tool').on('click', function (event) {
  if (event) event.preventDefault();
  google.script.run.preferencesPopup();
});

$('.open-divine-names-tool').on('click', function () {
  $('.hide').fadeIn('200');
  google.script.run.withSuccessHandler(function () {
    $('.hide').fadeOut('200');
  }).withFailureHandler(function () {
    $('.hide').fadeOut('200');
  }).transformDivineNames();
});

$('.open-linker-tool').on('click', function () {
  google.script.run.linkerHTML();
});

$('.open-ai-lesson-tool').on('click', function () {
  if ($(this).prop('disabled')) return;
  google.script.run.openAiLessonGenerator();
});

function bindDropdownToggle(selector) {
  var dropdown = $(selector);
  if (!dropdown.length) return;
  dropdown.find('.multi-select-button').on('click', function (event) {
    event.preventDefault();
    event.stopPropagation();
    $('.multi-select-dropdown').not(dropdown).removeClass('open').find('.multi-select-button').attr('aria-expanded', 'false');
    var willOpen = !dropdown.hasClass('open');
    dropdown.toggleClass('open', willOpen);
    dropdown.find('.multi-select-button').attr('aria-expanded', willOpen ? 'true' : 'false');
  });
}

$('.translation-language-toggle').on('click', function (event) {
  event.preventDefault();
  event.stopPropagation();
  var $dropdown = $('#translation-language-dropdown');
  var $menu = $('#translation-language-menu');
  var willOpen = !$dropdown.hasClass('open');
  $('.multi-select-dropdown').removeClass('open').find('.multi-select-button').attr('aria-expanded', 'false');
  $dropdown.toggleClass('open', willOpen);
  $menu.toggleClass('hidden', !willOpen);
  $(this).attr('aria-expanded', willOpen ? 'true' : 'false');
});

$(document).on('click', function (event) {
  if (!$(event.target).closest('.multi-select-dropdown, .translation-language-compact').length) {
    $('.multi-select-dropdown').removeClass('open').find('.multi-select-button').attr('aria-expanded', 'false');
    $('#translation-language-dropdown').removeClass('open');
    $('#translation-language-menu').addClass('hidden');
    $('#translation-language-toggle').attr('aria-expanded', 'false');
  }
});

function normalizeLanguage(version) {
  var suffixLanguageLUT = {
    en: 'English', he: 'Hebrew', ro: 'Romanian', yi: 'Yiddish', fr: 'French', de: 'German',
    es: 'Spanish', pt: 'Portuguese', ru: 'Russian', it: 'Italian', ar: 'Arabic', nl: 'Dutch',
    pl: 'Polish', hu: 'Hungarian', cs: 'Czech', uk: 'Ukrainian', tr: 'Turkish', lad: 'Ladino', su: 'Sundanese'
  };
  var lang = ((version.actualLanguage || version.language || "") + "").toLowerCase().trim();
  var family = (version.languageFamilyName || "").toString().trim();
  var normalizedFamily = family ? family.charAt(0).toUpperCase() + family.slice(1) : "";
  var title = (version.versionTitle || version.shortVersionTitle || '').toString().trim();
  var suffixMatch = title.match(/\[([a-z]{2,3})\]\s*$/i);
  var suffix = suffixMatch ? suffixMatch[1].toLowerCase() : '';
  var suffixLabel = suffixLanguageLUT[suffix] || '';
  var metadataLooksEnglish = ["en", "eng", "english"].indexOf(lang) >= 0 || /english/i.test(family);

  if (["he", "heb", "hebrew"].indexOf(lang) >= 0 || /hebrew/i.test(family)) return { key: "he", label: "HE" };
  if (metadataLooksEnglish) {
    if (suffix && suffix !== 'en' && suffixLabel) return { key: "other:" + suffix, label: suffix.toUpperCase() };
    return { key: "en", label: "EN" };
  }
  if (suffixLabel && normalizedFamily && /english/i.test(normalizedFamily) && suffix !== 'en') return { key: "other:" + suffix, label: suffix.toUpperCase() };
  if (!lang && normalizedFamily) return { key: "other:" + normalizedFamily.toLowerCase(), label: normalizedFamily.slice(0,2).toUpperCase() };
  if (!lang && suffixLabel) return { key: "other:" + suffix, label: suffix.toUpperCase() };
  if (!lang) return { key: "en", label: "EN" };
  return { key: "other:" + lang, label: String(lang).slice(0,2).toUpperCase() };
}

function extractYear(version) {
  var currentYear = (new Date()).getFullYear() + 1;
  var fields = [version.shortVersionTitle, version.versionTitle, version.versionNotes].filter(function (value) { return value; }).map(function (value) { return value.toString(); });
  var candidates = [];
  for (var i = 0; i < fields.length; i++) {
    var matches = fields[i].match(/\b(1\d{3}|20\d{2}|2100)\b/g);
    if (!matches) continue;
    for (var j = 0; j < matches.length; j++) {
      var numeric = parseInt(matches[j], 10);
      if (numeric >= 1000 && numeric <= currentYear) candidates.push(numeric);
    }
  }
  if (!candidates.length) return null;
  return Math.max.apply(null, candidates);
}

function buildVersionModel(dataIn) {
  var versions = Array.isArray(dataIn.versions) ? dataIn.versions : [];
  var seen = {};
  var normalized = [];
  versions.forEach(function (version, index) {
    var safeVersion = version || {};
    var language = normalizeLanguage(safeVersion);
    var versionTitle = safeVersion.versionTitle || safeVersion.shortVersionTitle || ("Untitled version #" + (index + 1));
    var dedupeKey = language.key + "::" + versionTitle + "::" + (safeVersion.versionSource || "");
    if (seen[dedupeKey]) return;
    seen[dedupeKey] = true;
    normalized.push({
      index: index,
      versionTitle: versionTitle,
      label: safeVersion.shortVersionTitle || safeVersion.versionTitle || versionTitle,
      fullTitle: safeVersion.versionTitle || versionTitle,
      languageKey: language.key,
      languageLabel: language.label,
      direction: safeVersion.direction,
      priority: Number(safeVersion.priority) || 0,
      isPrimary: !!safeVersion.isPrimary,
      year: extractYear(safeVersion)
    });
  });
  return normalized;
}

function sortVersionEntries(entries) {
  return entries.slice().sort(function (a, b) {
    if (a.year !== null && b.year !== null && a.year !== b.year) return b.year - a.year;
    if (a.year !== null && b.year === null) return -1;
    if (a.year === null && b.year !== null) return 1;
    var left = normalizeOptionText(a.fullTitle || a.label || a.versionTitle).toLowerCase();
    var right = normalizeOptionText(b.fullTitle || b.label || b.versionTitle).toLowerCase();
    var alpha = left.localeCompare(right);
    if (alpha !== 0) return alpha;
    if (a.priority !== b.priority) return b.priority - a.priority;
    return a.index - b.index;
  });
}

function languagePriorityKey(label) {
  var value = String(label || '').trim().toLowerCase();
  if (!value) return 2;
  if (value === preferredTranslationLanguage || (preferredTranslationLanguage === 'en' && value === 'english')) return 0;
  if (value === 'english' || value === 'en') return 1;
  return 2;
}

function renderPreviewHTML(dataIn, inputTitle) {
  var mode = $('.output-mode-selection').val();
  var layout = $('.bilingual-layout-selection').val() || 'he-right';

  if (mode === 'he') {
    return buildPreviewMeta(dataIn.heRef, dataIn) +
      "<div class='preview-he'>" +
      (dataIn.he || '<p class="preview-state-message">No source text available.</p>') +
      "</div>";
  }

  if (mode === 'en') {
    return buildPreviewMeta(dataIn.ref, inputTitle) +
      "<div>" +
      (dataIn.text || '<p class="preview-state-message">No translation text available.</p>') +
      "</div>";
  }

  var englishCell = "<td>" + buildPreviewMeta(dataIn.ref, inputTitle) + (dataIn.text || '<p class="preview-state-message">No translation text available.</p>') + "</td>";
  var hebrewCell = "<td class='preview-he'>" + buildPreviewMeta(dataIn.heRef, dataIn) + (dataIn.he || '<p class="preview-state-message">No source text available.</p>') + "</td>";

  if (layout === 'he-top') {
    return "<div class='preview-stack'>" +
      "<div class='preview-stack-block preview-he'>" + buildPreviewMeta(dataIn.heRef, dataIn) + (dataIn.he || '<p class="preview-state-message">No source text available.</p>') + "</div>" +
      "<div class='preview-stack-block'>" + buildPreviewMeta(dataIn.ref, inputTitle) + (dataIn.text || '<p class="preview-state-message">No translation text available.</p>') + "</div>" +
      "</div>";
  }

  if (layout === 'he-left') {
    return "<table class='preview-table'><tr>" + hebrewCell + englishCell + "</tr></table>";
  }

  return "<table class='preview-table'><tr>" + englishCell + hebrewCell + "</tr></table>";
}

function updateSuggestion(dataIn, inputTitle) {
  var resolvedRef = dataIn && dataIn.ref ? dataIn.ref : inputTitle;
  var versionEntries = buildVersionModel(dataIn);
  var enSelectedVersionTitle = dataIn.versionTitle || "";
  var heSelectedVersionTitle = dataIn.heVersionTitle || "";
  var hebrewEntries = sortVersionEntries(versionEntries.filter(function (entry) { return entry.languageKey === 'he'; }));
  var translationEntries = sortVersionEntries(versionEntries.filter(function (entry) { return entry.languageKey !== 'he'; }));

  var selectVersionHebrew = "<div class=\"version-control-header\"><label class=\"version-label\" for=\"he-version-filter\">Source editions</label><span class=\"version-count\">" + hebrewEntries.length + " available</span></div><input type=\"text\" id=\"he-version-filter\" class=\"translation-filter-input he-version-filter\" placeholder=\"Filter source editions\" aria-label=\"Filter source editions\"><select id=\"he-version-selection\" class=\"translation-version-select he-version-selection\" size=\"6\" aria-label=\"Source editions\"></select><div class=\"translation-selected-display he-selected-display\" aria-live=\"polite\"></div>";

  var translationInput = "<div class=\"version-control-header\"><label class=\"version-label\" for=\"translation-version-filter\">Translation versions</label><span class=\"version-count\">" + translationEntries.length + " available</span></div><input type=\"text\" id=\"translation-version-filter\" class=\"translation-filter-input\" placeholder=\"Filter by language or version name\" aria-label=\"Filter translation versions\"><select id=\"translation-version-selection\" class=\"translation-version-select\" size=\"6\" aria-label=\"Translation versions\"></select><div class=\"translation-selected-display\" aria-live=\"polite\"></div>";

  var languageGroups = {};
  translationEntries.forEach(function (entry) {
    if (!languageGroups[entry.languageLabel]) languageGroups[entry.languageLabel] = [];
    languageGroups[entry.languageLabel].push(entry);
  });

  var translationGroupLabels = Object.keys(languageGroups).sort(function (a, b) {
    var diff = languagePriorityKey(a) - languagePriorityKey(b);
    if (diff !== 0) return diff;
    if (String(a || '').toLowerCase() === String(b || '').toLowerCase()) return 0;
    return String(a || '').localeCompare(String(b || ''));
  });

  var translationItems = [];
  translationGroupLabels.forEach(function (groupLabel) {
    var cleanGroupLabel = (normalizeOptionText(groupLabel).slice(0,2).toUpperCase()) || 'OT';
    if (!languageGroups[groupLabel] || !languageGroups[groupLabel].length) return;
    languageGroups[groupLabel].forEach(function (entry) {
      var cleanLabel = normalizeOptionText(entry.fullTitle || entry.label || entry.versionTitle);
      var fallbackLabel = normalizeOptionText(entry.versionTitle);
      var normalizedLabel = cleanLabel || fallbackLabel || ("Translation " + (entry.index + 1));
      var optionLabel = normalizeOptionText(cleanGroupLabel + " – " + normalizedLabel);
      translationItems.push({
        label: normalizedLabel,
        optionLabel: optionLabel,
        value: entry.versionTitle,
        category: cleanGroupLabel,
        searchable: (normalizedLabel + " " + entry.versionTitle + " " + cleanGroupLabel).toLowerCase(),
        availableForRef: Object.prototype.hasOwnProperty.call(translationAvailabilityByRef, resolvedRef + "::" + entry.versionTitle)
          ? translationAvailabilityByRef[resolvedRef + "::" + entry.versionTitle]
          : true
      });
    });
  });

  var hebrewItems = hebrewEntries.map(function (entry) {
    var normalizedLabel = normalizeOptionText(entry.fullTitle || entry.label || entry.versionTitle) || normalizeOptionText(entry.versionTitle) || ("Source " + (entry.index + 1));
    return {
      label: normalizedLabel,
      optionLabel: normalizedLabel,
      value: entry.versionTitle,
      searchable: (normalizedLabel + " " + entry.versionTitle).toLowerCase()
    };
  });

  $('.translation-version-control').html(translationInput);
  $('.hebrew-version-control').html(selectVersionHebrew);
  $('.suggestions').html(renderPreviewHTML(dataIn, inputTitle));

  if (pendingPreferredVersions) {
    var preferredEn = pendingPreferredVersions.en || '';
    var preferredHe = pendingPreferredVersions.he || '';
    if (preferredEn && translationEntries.some(function (entry) { return entry.versionTitle === preferredEn; })) enSelectedVersionTitle = preferredEn;
    if (preferredHe && hebrewEntries.some(function (entry) { return entry.versionTitle === preferredHe; })) heSelectedVersionTitle = preferredHe;
  }

  var currentEnVersion = enSelectedVersionTitle;
  var currentHeVersion = heSelectedVersionTitle;

  function syncSelectedTranslationDisplay() {
    var selectedOption = $('.translation-version-select option:selected').first();
    var displayText = normalizeOptionText(selectedOption.attr('title') || selectedOption.text() || 'No translation selected.');
    $('.translation-selected-display').first().text(displayText).attr('title', displayText);
  }

  function syncSelectedHebrewDisplay() {
    var selectedOption = $('.he-version-selection option:selected').first();
    var displayText = normalizeOptionText(selectedOption.attr('title') || selectedOption.text() || 'No source edition selected.');
    $('.he-selected-display').text(displayText).attr('title', displayText);
  }

  function markTranslationAvailability(resolvedVersionTitle, attemptedVersionTitle) {
    var resolved = String(resolvedVersionTitle || '').trim();
    var attempted = String(attemptedVersionTitle || '').trim();
    if (!attempted) return;
    var wasResolved = !!(resolved && resolved === attempted);
    translationAvailabilityByRef[resolvedRef + '::' + attempted] = wasResolved;
    translationItems.forEach(function (item) {
      if (item.value === attempted) item.availableForRef = wasResolved;
    });
  }

  function renderTranslationOptions(filterTerm) {
    var query = String(filterTerm || '').trim().toLowerCase();
    var filtered = translationItems.filter(function (item) { return !query || item.searchable.indexOf(query) >= 0; });
    var optionsHTML = '';
    var hasSelectableOption = false;

    if (!filtered.length) {
      optionsHTML = '<option value="" disabled>No matching translations</option>';
    } else {
      filtered.forEach(function (item) {
        var isUnavailable = item.availableForRef === false;
        var selected = item.value === currentEnVersion && !isUnavailable ? 'selected' : '';
        var disabled = isUnavailable ? 'disabled' : '';
        var label = isUnavailable ? (item.optionLabel + ' – unavailable for this ref') : item.optionLabel;
        if (!isUnavailable) hasSelectableOption = true;
        optionsHTML += '<option value="' + escapeHTML(item.value) + '" ' + selected + ' ' + disabled + ' title="' + escapeHTML(label) + '">' + escapeHTML(label) + '</option>';
      });
    }

    if (!hasSelectableOption && filtered.length) {
      optionsHTML += '<option value="" disabled>No available translations for this ref</option>';
    }

    $('.translation-version-select').html(optionsHTML);
    if (!$('.translation-version-select').val()) {
      var firstEnabled = $('.translation-version-select option:not(:disabled)').first();
      if (firstEnabled.length) {
        firstEnabled.prop('selected', true);
        currentEnVersion = firstEnabled.val();
      }
    }
    if (currentEnVersion && !$('.translation-version-select option:selected').length) currentEnVersion = '';
    syncSelectedTranslationDisplay();
  }

  function renderHebrewOptions(filterTerm) {
    var query = String(filterTerm || '').trim().toLowerCase();
    var filtered = hebrewItems.filter(function (item) { return !query || item.searchable.indexOf(query) >= 0; });
    var optionsHTML = '';

    if (!filtered.length) {
      optionsHTML = '<option value="" disabled>No matching source editions</option>';
    } else {
      filtered.forEach(function (item) {
        var selected = item.value === currentHeVersion ? 'selected' : '';
        optionsHTML += '<option value="' + escapeHTML(item.value) + '" ' + selected + ' title="' + escapeHTML(item.optionLabel) + '">' + escapeHTML(item.optionLabel) + '</option>';
      });
    }

    $('.he-version-selection').html(optionsHTML);
    if (!$('.he-version-selection').val()) {
      var firstOption = $('.he-version-selection option:not(:disabled)').first();
      if (firstOption.length) {
        firstOption.prop('selected', true);
        currentHeVersion = firstOption.val();
      }
    }
    if (currentHeVersion && !$('.he-version-selection option:selected').length) currentHeVersion = '';
    syncSelectedHebrewDisplay();
  }

  function getVersions(targetTranslationVersion) {
    var selectedTranslation = targetTranslationVersion || $('.translation-version-select').val();
    var enVersion = selectedTranslation || currentEnVersion || enSelectedVersionTitle;
    var heVersion = $('.he-version-selection').val() || currentHeVersion || heSelectedVersionTitle;
    var versions = { en: enVersion, he: heVersion };
    var requestId = ++latestResolveRequestId;
    hasResolvedReference = false;
    setInsertButtonState(false);
    $('#open-on-sefaria').prop('disabled', true);
    $('.suggestions').html(buildPreviewLoadingHTML('Refreshing preview…'));

    google.script.run.withSuccessHandler(function (response) {
      if (requestId !== latestResolveRequestId) return;
      var nodeState = getResolvedNodeState(response);
      if (!nodeState.isInsertable) {
        hasResolvedReference = false;
        setInsertButtonState(false);
        $('#open-on-sefaria').prop('disabled', true);
        clearVersionSelectors();
        updatePesukimAvailability(null);
        updateActionabilityUI(nodeState);
        $('.suggestions').html('<br>' + buildNonInsertableMessage(response));
        return;
      }

      var resolvedTranslation = String((response && response.versionTitle) || '').trim();
      markTranslationAvailability(resolvedTranslation, enVersion);
      if (enVersion && resolvedTranslation && resolvedTranslation !== enVersion) renderTranslationOptions($('.translation-filter-input').val());
      updateSuggestion(response, inputTitle);
      updatePesukimAvailability(response);
      updateActionabilityUI(nodeState);
      data = response;
      hasResolvedReference = true;
      setInsertButtonState(true);
      $('#open-on-sefaria').prop('disabled', false);
    }).withFailureHandler(function () {
      if (requestId !== latestResolveRequestId) return;
      markTranslationAvailability('', enVersion);
      renderTranslationOptions($('.translation-filter-input').val());
      hasResolvedReference = false;
      setInsertButtonState(false);
      $('#open-on-sefaria').prop('disabled', true);
      clearVersionSelectors();
      updatePesukimAvailability(null);
      updateActionabilityUI({ isInsertable: false });
    }).findReference(resolvedRef, versions);
  }

  renderTranslationOptions('');
  renderHebrewOptions('');

  $('.translation-filter-input').off('input.translationFilter').on('input.translationFilter', function () {
    if ($(this).hasClass('he-version-filter')) renderHebrewOptions($(this).val());
    else renderTranslationOptions($(this).val());
  }).off('keydown.translationFilter').on('keydown.translationFilter', function (event) {
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      if ($(this).hasClass('he-version-filter')) $('.he-version-selection').focus();
      else $('.translation-version-select').focus();
    }
  });

  $('.translation-version-select').off('change.translationVersion').on('change.translationVersion', function () {
    var selected = $(this).val();
    syncSelectedTranslationDisplay();
    if (!selected) return;
    currentEnVersion = selected;
    getVersions(selected);
  });

  $('.he-version-selection').off('change.heVersion').on('change.heVersion', function () {
    var selected = $(this).val();
    syncSelectedHebrewDisplay();
    if (!selected) return;
    currentHeVersion = selected;
    getVersions();
  });

  if (pendingPreferredVersions) {
    var prefEn = pendingPreferredVersions.en || '';
    var prefHe = pendingPreferredVersions.he || '';
    pendingPreferredVersions = null;
    if (prefEn || prefHe) {
      var currentEn = $('.translation-version-select').val() || currentEnVersion || enSelectedVersionTitle;
      var currentHe = $('.he-version-selection').val() || currentHeVersion || heSelectedVersionTitle;
      if (currentEn !== (dataIn.versionTitle || '') || currentHe !== (dataIn.heVersionTitle || '')) getVersions();
    }
  }

  updateVersionControlsVisibility();
  updateModeDependentSections();
}


$(document).on('click', '.results-suggestion-button', function (event) {
  event.preventDefault();
  var suggestion = $(this).attr('data-suggested-query') || $(this).text();
  $('.input').val(suggestion);
  updateQueryIntel(suggestion);
  runUnifiedQuery();
});

$('.results-restore-button').on('click', function (event) {
  event.preventDefault();
  resultPostProcessState.removedCorpora = [];
  reprocessAndRenderResults();
});

$(document).on('change', '.translation-language-any', function () {
  if ($(this).is(':checked')) {
    $('.translation-language-option').prop('checked', false);
  }
  updateTranslationLanguageVisibility();
  saveLastUsedSearchSettings();
  if (getAllRawResults().length) {
    reprocessAndRenderResults();
  } else if (($('.input').val() || '').trim()) {
    runUnifiedQuery();
  }
});

$(document).on('change', '.translation-language-option', function () {
  if ($(this).is(':checked')) {
    $('.translation-language-any').prop('checked', false);
  } else if (!$('.translation-language-option:checked').length) {
    $('.translation-language-any').prop('checked', true);
  }
  updateTranslationLanguageVisibility();
  saveLastUsedSearchSettings();
  if (getAllRawResults().length) {
    reprocessAndRenderResults();
  } else if (($('.input').val() || '').trim()) {
    runUnifiedQuery();
  }
});

$('.session-library-panel').on('click keydown', '.session-library-item', function (event) {
  if (event.type === 'keydown' && event.key !== 'Enter' && event.key !== ' ') return;
  if ($(event.target).closest('.session-library-remove').length) return;
  event.preventDefault();
  var ref = $(this).attr('data-ref');
  if (ref) {
    $('.input').val(ref);
    $('#session-library-modal').attr('hidden', true);
    runUnifiedQuery();
    setTimeout(function () {
      var match = queryState.libraryMatches.concat(queryState.searchResults).find(function(item){ return item && item.ref === ref; });
      if (match && match.key) {
        selectedResultKey = match.key;
        selectedResultSummary = { label: match.ref || match.label, subtitle: match.subtitle || '' };
        updateResultsVisibility();
        resolveSelectedResult(match.ref, match.ref || match.label);
      }
    }, 250);
  }
});

$('.session-library-panel').on('click', '.session-library-remove', function (event) {
  event.preventDefault();
  event.stopPropagation();
  removeSessionEntry($(this).attr('data-list'), $(this).attr('data-ref'));
});

$('.results-panel').on('click', '.result-pin-button', function (event) {
  event.preventDefault();
  event.stopPropagation();
  togglePinnedRef($(this).attr('data-ref'), $(this).attr('data-label'));
});

$('.output-mode-selection').on('change', function () {
  updateBilingualLayoutVisibility();
  updateTranslationDetailsVisibility();
  updateHebrewOptionsVisibility();
  updateVersionControlsVisibility();
  updateTransliterationVisibility();
  syncDisplayModeCards();
  saveSidebarPreference({ output_mode_default: $('.output-mode-selection').val() });
  if (hasResolvedReference && data && data.ref) {
    updateSuggestion(data, selectedResultSummary ? selectedResultSummary.label : data.ref);
  }
});

$('.mode-card').on('click keydown', function (event) {
  if (event.type === 'keydown' && event.key !== 'Enter' && event.key !== ' ') return;
  event.preventDefault();
  $('.output-mode-selection').val($(this).attr('data-mode')).trigger('change');
});

$('.layout-option').on('click keydown', function (event) {
  if (event.type === 'keydown' && event.key !== 'Enter' && event.key !== ' ') return;
  event.preventDefault();
  $('.bilingual-layout-selection').val($(this).attr('data-layout'));
  syncLayoutCards();
  saveSidebarPreference({ bilingual_layout_default: $('.bilingual-layout-selection').val() });
  if (hasResolvedReference && data && data.ref) {
    updateSuggestion(data, selectedResultSummary ? selectedResultSummary.label : data.ref);
  }
});

function initializeSidebar(receivedTitles) {
  titles = Array.isArray(receivedTitles) ? receivedTitles : [];
  $(".input").removeAttr("disabled");
  $('.suggestions').html("<b>Please enter the title of a text or a source to insert.</b>");
  // Legacy jQuery UI autocomplete removed. Unified debounced search now drives suggestions/results.

  loadSessionLibrary();
  renderSessionLibrary();
  updateTranslationLanguageVisibility();
  syncCompactTranslationLanguageUI();
  updateQueryIntel('');
  updateBilingualLayoutVisibility();
  updateTranslationDetailsVisibility();
  updateHebrewOptionsVisibility();
  updateVersionControlsVisibility();
  updateTransliterationVisibility();
  syncDisplayModeCards();
  syncLayoutCards();
  ensureResultFilterUI();
  $('.results-restore-button').hide();
  renderResults();
  renderSessionLibrary();
  setInsertButtonState(false);
  syncSessionOverrideButtons();
}

google.script.run.withSuccessHandler(function (receivedTitles) {
  initializeSidebar(receivedTitles);
}).withFailureHandler(function () {
  initializeSidebar([]);
}).returnTitles();

$('.close').click(function () {
  google.script.host.close();
});



var appMode = window.INITIAL_SIDEBAR_MODE || 'basic';
var selectedVoiceItem = null;
var originalTextRunUnifiedQuery = runUnifiedQuery;
var originalResolveSelectedResult = resolveSelectedResult;
var originalRefreshSelectedResult = refreshSelectedResult;
var originalBuildSessionEntry = buildSessionEntry;

function setSidebarMode(mode, skipPreferenceSave) {
  appMode = (mode === 'advanced' || mode === 'voices') ? mode : 'basic';
  $('body').removeClass('mode-basic mode-advanced mode-voices').addClass('mode-' + appMode);
  $('.unified-sidebar').attr('data-mode', appMode);
  $('.mode-switch-button').removeClass('is-active').attr('aria-pressed', 'false');
  $('.mode-switch-button[data-sidebar-mode="' + appMode + '"]').addClass('is-active').attr('aria-pressed', 'true');
  $('.voices-only').toggle(appMode === 'voices');
  $('.text-mode-only').toggle(appMode !== 'voices');
  $('.reference-row .search-submit').toggle(appMode !== 'basic');
  $('.advanced-version-details').toggle(appMode === 'advanced' && $('.output-mode-selection').val() !== 'en');
  $('.input').attr('placeholder', appMode === 'voices' ? 'Search source sheets' : (appMode === 'advanced' ? 'Reference, title, or phrase' : 'Search for a text'));
  $('.session-library-panel').toggle(appMode !== 'basic');
  $('.search-results-label').text(appMode === 'voices' ? 'Source Sheets' : 'Search results');
  $('#insert-source').text(appMode === 'voices' ? 'Add Link' : 'Add Source');
  $('.open-label-text').text(appMode === 'voices' ? 'Open Sheet' : 'Open');
  if (!skipPreferenceSave) saveAccountPreference({ search_mode: appMode });
  syncSessionOverrideButtons();
  updateModeDependentSections();
}

function updateModeDependentSections() {
  var hasSearch = !!(($('.input').val() || '').trim()) || getAllRawResults().length > 0;
  var hasSelectedTextResult = appMode !== 'voices' && !!selectedResultKey;
  var hasSelectedVoiceResult = appMode === 'voices' && !!selectedVoiceItem;
  var hideTranslations = $('.translation-version-select option:not(:disabled)').length <= 1;
  $('.results-panel').toggle(hasSearch);
  $('.display-layout-shell').toggle(hasSelectedTextResult);
  $('.more-options-accordion').toggle(appMode === 'advanced' && hasSelectedTextResult);
  $('.versions-section').toggle(hasSelectedTextResult && !hideTranslations);
  $('.preview-section').toggle(hasSelectedTextResult || hasSelectedVoiceResult);
  syncSessionOverrideButtons();
  if (appMode === 'basic') {
    $('#session-library-modal').attr('hidden', true);
  }
  renderSessionLibrary();
}

function buildSessionEntry(ref, label, corpusLabel, extra) {
  var entry = originalBuildSessionEntry(ref, label, corpusLabel);
  extra = extra || {};
  entry.mode = extra.mode || (appMode === 'voices' ? 'voices' : 'text');
  entry.url = extra.url || '';
  entry.query = extra.query || label || ref;
  return entry;
}

function syncSessionLibraryFilterOptions() {
  var seen = {};
  var options = [{ key: 'all', label: 'All Corpora' }];
  (sessionLibrary.pinned || []).concat(sessionLibrary.inserted || []).forEach(function(item) {
    var label = String((item && item.corpusLabel) || 'Other');
    var key = label.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'other';
    if (seen[key]) return;
    seen[key] = true;
    options.push({ key: key, label: label });
  });
  var $select = $('#session-library-corpus-filter');
  if (!$select.length) return;
  $select.html(options.map(function(option){
    return "<option value='" + escapeHTML(option.key) + "'>" + escapeHTML(option.label) + "</option>";
  }).join(''));
  if (!$select.find("option[value='" + sessionLibraryFilter + "']").length) sessionLibraryFilter = 'all';
  $select.val(sessionLibraryFilter);
  $select.toggle(options.length > 2);
}

function getSessionEntryCorpusKey(item) {
  return String((item && item.corpusLabel) || 'Other').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'other';
}

function renderSessionLibrary() {
  var $panel = $('.session-library-panel');
  var $pinned = $('.pinned-results');
  var $inserted = $('.inserted-results');
  if (!$panel.length) return;
  $pinned.empty();
  $inserted.empty();

  syncSessionLibraryFilterOptions();

  function renderGrouped($target, items, allowRemove) {
    var groups = {};
    (items || []).forEach(function(item) {
      var corpus = String((item && item.corpusLabel) || 'Other');
      var corpusKey = getSessionEntryCorpusKey(item);
      if (sessionLibraryFilter !== 'all' && corpusKey !== sessionLibraryFilter) return;
      if (!groups[corpus]) groups[corpus] = [];
      groups[corpus].push(item);
    });

    Object.keys(groups).sort().forEach(function(corpus) {
      $target.append("<li class='session-corpus-group'>" + escapeHTML(corpus) + "</li>");
      groups[corpus].forEach(function(item) {
        var removeBtn = allowRemove ? "<button type='button' class='session-library-remove' data-list='pinned' data-ref='" + escapeHTML(item.ref) + "' aria-label='Remove pinned item'>×</button>" : "";
        $target.append("<li class='result-item session-library-item' data-ref='" + escapeHTML(item.ref) + "' data-url='" + escapeHTML(item.url || '') + "' data-mode='" + escapeHTML(item.mode || 'text') + "' data-query='" + escapeHTML(item.query || item.label || item.ref) + "' data-list='" + (allowRemove ? 'pinned' : 'inserted') + "' role='button' tabindex='0'><div class='result-title session-library-label'>" + escapeHTML(item.label || item.ref) + "</div>" + removeBtn + "</li>");
      });
    });
  }

  renderGrouped($pinned, sessionLibrary.pinned || [], true);
  renderGrouped($inserted, sessionLibrary.inserted || [], false);
  var hasItems = !!(sessionLibrary.pinned.length || sessionLibrary.inserted.length);
  var hasVisibleItems = !!($pinned.children().length || $inserted.children().length);
  $('.session-library-group').toggle(hasVisibleItems);
  $panel.toggle(hasItems);
  $('.session-library-panel .results-hint').remove();
  if (hasItems && !hasVisibleItems) {
    $panel.append("<p class='results-hint'>No pinned or recent items match this corpus filter.</p>");
  }
}

function runVoicesQuery() {
  var input = normalizeUnifiedReferenceInput(($('.input').val() || '').trim());
  $('.input').val(input);
  clearSelectedResult();
  selectedVoiceItem = null;
  setResultsHint('');
  updateModeDependentSections();
  if (!input) {
    queryState = { rawLibraryMatches: [], rawSearchResults: [], libraryMatches: [], searchResults: [] };
    reprocessAndRenderResults();
    setInsertButtonState(false);
    $('#open-on-sefaria').prop('disabled', true);
    return;
  }
  setResultsLoading(true);
  google.script.run.withSuccessHandler(function(response) {
    var items = Array.isArray(response) ? response : [];
    queryState.rawLibraryMatches = [];
    queryState.rawSearchResults = items;
    reprocessAndRenderResults();
    if (!items.length) setResultsHint('No source sheets matched this search.');
    updateModeDependentSections();
    setResultsLoading(false);
  }).withFailureHandler(function(error) {
    queryState.rawLibraryMatches = [];
    queryState.rawSearchResults = [];
    reprocessAndRenderResults();
    setResultsHint((error && error.message) || 'Voices search is temporarily unavailable.');
    setResultsLoading(false);
  }).searchVoices(input, {});
}

runUnifiedQuery = function() {
  if (appMode === 'voices') {
    return runVoicesQuery();
  }
  updateModeDependentSections();
  return originalTextRunUnifiedQuery();
};

resolveSelectedResult = function(selectedRef, inputLabel) {
  if (appMode === 'voices') {
    var item = queryState.searchResults.concat(queryState.libraryMatches).find(function(result){ return result && result.ref === selectedRef; }) || null;
    selectedVoiceItem = item;
    selectedRefValue = selectedRef;
    hasResolvedReference = false;
    if (selectedResultSummary) {
      selectedResultSummary.status = item ? 'Ready to insert' : '';
      updateResultsVisibility();
    }
    setInsertButtonState(!!item);
    $('#open-on-sefaria').prop('disabled', !(item && item.url));
    if (item) {
      var snippet = normalizeOptionText(item.snippet || item.summary || '');
      var previewHtml = "<div class='voice-preview'><div class='voice-preview-title'>" + escapeHTML(item.label || item.ref || 'Source sheet') + "</div>";
      if (snippet) previewHtml += "<div class='voice-preview-snippet'>" + escapeHTML(snippet) + "</div>";
      if (item.url) previewHtml += "<div class='voice-preview-link'>Open on Sefaria with the footer button.</div>";
      previewHtml += "</div>";
      $('.suggestions').html(previewHtml);
    } else {
      $('.suggestions').html("<b>Select a source sheet to preview it.</b>");
    }
    updateModeDependentSections();
    return;
  }
  selectedVoiceItem = null;
  updateModeDependentSections();
  return originalResolveSelectedResult(selectedRef, inputLabel);
};

refreshSelectedResult = function() {
  if (appMode === 'voices') return;
  return originalRefreshSelectedResult();
};

function handleInsertAction() {
  if (appMode === 'voices') {
    if (!selectedVoiceItem) return;
    $('.hide').fadeIn('150');
    google.script.run.withSuccessHandler(function () {
      $('.hide').fadeOut('150');
      upsertSessionEntry('inserted', buildSessionEntry(selectedVoiceItem.ref, selectedVoiceItem.label, 'Source Sheets', {
        mode: 'voices',
        url: selectedVoiceItem.url,
        query: selectedVoiceItem.label
      }));
    }).withFailureHandler(function (error) {
      $('.hide').fadeOut('150');
      showInsertWarning(error && error.message ? error.message : 'Could not insert this source sheet.');
    }).insertSheetReference(selectedVoiceItem);
    return;
  }

  if (!hasResolvedReference || !data || !data.ref) return;
  var outputMode = $('.output-mode-selection').val();
  var language = (outputMode === 'both') ? undefined : outputMode;
  var bilingualLayout = $('.bilingual-layout-selection').val();
  var showPesukim = Boolean($('.wants-pesukim').prop('checked'));
  var includeTranslationSourceInfo = $('.include-translation-source-info').is(':checked');
  var insertSefariaLink = $('.insert-sefaria-link').is(':checked');
  var input = $('.input').val();

  $('.hide').add($('.warning')).fadeIn('1000');
  google.script.run.withSuccessHandler(function () {
    $('.hide').add($('.warning')).fadeOut('1000');
    $('.insert-warning').remove();
    upsertSessionEntry('inserted', buildSessionEntry(data.ref, selectedResultSummary && selectedResultSummary.label ? selectedResultSummary.label : data.ref, getCurrentCorpusForRef(data.ref), { mode: 'text', query: input }));
  }).withFailureHandler(function (error) {
    $('.hide').add($('.warning')).fadeOut('1000');
    showInsertWarning(error && error.message);
  }).insertReference(
    data,
    language,
    showPesukim,
    input,
    includeTranslationSourceInfo,
    bilingualLayout,
    insertSefariaLink,
    $('.include-transliteration').is(':checked'),
    $('.insert-citation-only').is(':checked')
  );
}

function handleOpenAction() {
  if (appMode === 'voices') {
    if (selectedVoiceItem && selectedVoiceItem.url) window.open(selectedVoiceItem.url, '_blank');
    return;
  }
  var url = buildSefariaOpenUrl();
  if (url) window.open(url, '_blank');
}

$('#insert-source').off('click').on('click', handleInsertAction);
$('#open-on-sefaria').off('click').on('click', handleOpenAction);
$('#run-sefaria').off('click').on('click', runUnifiedQuery);
$('#open-session-library').off('click').on('click', function () {
  if (appMode !== 'advanced') return;
  renderSessionLibrary();
  $('#session-library-modal').removeAttr('hidden');
});
$('#close-session-library').off('click').on('click', function () {
  $('#session-library-modal').attr('hidden', true);
});
$('#session-library-modal').off('click.dismiss').on('click.dismiss', function (event) {
  if (event.target === this) $('#session-library-modal').attr('hidden', true);
});
$(document).off('keydown.sessionLibrary').on('keydown.sessionLibrary', function (event) {
  if (event.key === 'Escape') $('#session-library-modal').attr('hidden', true);
});
$('.mode-switch-button').off('click').on('click', function() {
  var nextMode = $(this).attr('data-sidebar-mode');
  setSidebarMode(nextMode);
  clearSelectedResult();
  selectedVoiceItem = null;
  setInsertButtonState(false);
  $('#open-on-sefaria').prop('disabled', true);
  if (($('.input').val() || '').trim()) runUnifiedQuery();
  else updateModeDependentSections();
});
$('#restore-corpus-select').on('change', function() {
  var selected = $(this).val();
  if (!selected) return;
  toggleCorpusVisibility(selected);
  $(this).val('');
});
$('#session-library-corpus-filter').on('change', function() {
  sessionLibraryFilter = $(this).val() || 'all';
  renderSessionLibrary();
});
$('.translation-language-menu').on('click', '.translation-language-choice, .translation-language-more-toggle', function () {
  window.setTimeout(function(){ $('#translation-language-toggle').attr('aria-expanded', $('#translation-language-dropdown').hasClass('open') ? 'true' : 'false'); }, 0);
});
$('.results-panel').off('click', '.result-pin-button').on('click', '.result-pin-button', function (event) {
  event.preventDefault();
  event.stopPropagation();
  var ref = $(this).attr('data-ref');
  var item = queryState.libraryMatches.concat(queryState.searchResults).find(function(result){ return result && result.ref === ref; });
  if (!item) return;
  if (isPinnedRef(ref)) removeSessionEntry('pinned', ref);
  else upsertSessionEntry('pinned', buildSessionEntry(item.ref, item.label, getResultCorpusLabel(item, appMode === 'voices' ? 'Source Sheets' : 'Other'), {
    mode: appMode === 'voices' ? 'voices' : 'text',
    url: item.url || '',
    query: item.label || item.ref
  }));
  renderResults();
});
$('.session-library-panel').off('click keydown', '.session-library-item').on('click keydown', '.session-library-item', function (event) {
  if (event.type === 'keydown' && event.key !== 'Enter' && event.key !== ' ') return;
  if ($(event.target).closest('.session-library-remove').length) return;
  event.preventDefault();
  var itemMode = $(this).attr('data-mode') || 'text';
  var query = $(this).attr('data-query') || $(this).attr('data-ref');
  setSidebarMode(itemMode === 'voices' ? 'voices' : 'advanced', true);
  if (query) {
    $('.input').val(query);
    runUnifiedQuery();
  }
});

$('.reset-session-overrides-button').off('click').on('click', function () {
  resetSessionOverrides();
});

$('.save-session-defaults-button').off('click').on('click', function () {
  saveSessionAsDefaults();
});

setSidebarMode(appMode, true);
updateModeDependentSections();

function updateDisplayChoiceSummaries(){
  var modeLabelMap={he:'Original',en:'Translation',both:'Bilingual'};
  var layoutLabelMap={'he-right':'Right–Left','he-left':'Left–Right','he-top':'Stacked'};
  var mode=$('.output-mode-selection').val()||'both';
  var layout=$('.bilingual-layout-selection').val()||'he-right';
  $('#display-choice-summary-text').text(modeLabelMap[mode]||'Original with Translation');
  $('#layout-choice-summary-text').text(layoutLabelMap[layout]||'Right–Left');
}
$('.output-mode-selection').on('change', updateDisplayChoiceSummaries);
$('.bilingual-layout-selection').on('change', updateDisplayChoiceSummaries);
$(document).ready(updateDisplayChoiceSummaries);



