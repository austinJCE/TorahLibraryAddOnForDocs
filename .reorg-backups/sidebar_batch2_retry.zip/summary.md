# Sidebar fix batch 2 (retry)

Updated files:
- main.html
- main_js.html
- main_css.html
- Code.gs

This batch re-applies the sidebar fixes against your latest uploaded files:
1. Restored dynamic More Options behavior with citation-only mode.
2. Reduced and middle-aligned Vowels / Cantillation controls and toggles.
3. Added Insert citation back to the sidebar and backend insertion.
4. Renamed Source references in the sidebar to Original where practical.
5. Docked the footer at the bottom of the sidebar.
6. Prevented Show results overflow and moved it into its own row above the selected item.
7. Restyled Rel. as a minimal borderless result refinement control.
8. Colored corpus filters and kept removed ones greyed with the restore symbol.
9. Suppressed duplicate library hits.
10. Grouped Session Library entries by corpus without corpus filter chips.
11. Added compact translation-language dropdown behavior in the Results area.
12. Preserved transliteration gematria line-marker behavior in Code.gs while adding citation-mode support and default-preference merging.
